<?php require_once("../resources/config.php");   ?>
<?php include(TEMPLATE_FRONT.DS."header.php");?>
<?php
  if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
    redirect("login.php");
  }
?>
<?php
  if(isset($_GET['hall_id'])){
    $query = query("SELECT * FROM marriage_hall_line WHERE marriage_hall_line_id='{$_GET['hall_id']}'");
    confirm($query);
    while ($row = fetch_array($query)) {
      $_SESSION['hall_id'] = $row['marriage_hall_line_id'];
      $capacity = $row['capacity'];
      //$marriage_id = $row['marriage_hall_id'];
    }
  }
?>
  <h2 align="center">Add Booking Detail</h2>
  <br />
  <form method="post" action="checkout.php">
    <input type="hidden" name="marriage-hall" value="<?php echo $_GET['m_id']; ?>">
    <input type="hidden" name="hall" value="<?php echo $_GET['hall_id']; ?>">
    <div class="container">
      <div class="row">
        <div class="col-md-8">
          <div id="calendar"></div>
        </div>
        <div class="col-md-4">
          <label>Booking Date</label>
          <input type="text" name="event-date" id="event-date" class="form-control" required onkeydown="return false;" style="caret-color: transparent !important;">
          <label>Shift</label>
          <select name="event-shift" id="event-shift" class="form-control" required>
            <option value="">Select Any One:</option>
            <option value="0">Noon: 12 PM to 5 PM</option>
            <option value="1">Evening: 6 PM to 10 PM</option>
          </select>
          <label>No. of Guest</label>
          <input type="text" name="event-guest" id="guests" class="form-control" required>
          <span id="hall-guests"></span>
        </div>
      </div>
    </div>
    <section class="pricing-section set-bg spad" data-setbg="img/pricing-bg.jpg">
          <div class="container">
              <div class="row">
                  <div class="col-lg-12">
                      <div class="section-title">
                          <h2>Deals</h2>
                          <p>Get your event deals</p>
                      </div>
                  </div>
              </div>
              <div class="row justify-content-center">
                  <?php deal_service(); ?>
                  <!-- <div class="col-lg-4 col-md-8">
                      <div class="price-item">
                          <h4>Custom Menu</h4>
                          <div class="pi-price">
                              <h2>RS:---</h2>
                          </div>
                          <ul>
                            <li>Here You Can choose menu on Your Choice</li>
                          </ul>
                          <div class="price-btn">
                            <input type="radio" name="deal" value="0" required> Get Deal
                          </div>
                      </div>
                  </div> -->
              </div>
              <div class="row" style="float:right;">
                  <input type="submit" name="submit" value="Next" class="btn btn-primary btn-lg" id="next">
              </div>
              
          </div>
        </section>
  </form>
  <?php include(TEMPLATE_FRONT.DS."footer.php");?>
<script>
   
    $(document).ready(function() {
      //display_booking();
      $("#guests").blur(function() {
      var guest = $(this).val();
      var capacity = '<?php echo $capacity; ?>';
      if(guest>capacity)
      {
        alert("You can't add more than capacity");
        $('#hall-guests').html('<span class="text-danger">You cannot add more than capacity </span>');
        $('#next').attr("disabled",true);
      }
      else
      {
        capacity = $('#guests').val();
        $('#hall-guests').html('<span class="text-danger"> </span>');
        $('#next').attr("disabled",false);
      }
    });
      var booking = new Array();
        $.ajax({
          url:'display_booking.php',
          dataType:'json',
          success:function(response)
          {
            var result = response.data;
            $.each(result,function(i,item){
              booking.push({
                id:result[i].booking_id,
                date:result[i].booking_date,
                title:result[i].title,
                color:result[i].color,
                textColor:result[i].textColor

              });
            })
            var calendar = $('#calendar').fullCalendar({
            defaultView: 'month',
            timeZone: 'local',
            //editable: true,
            selectable: true,
            selectHelper: true,
            select: function(date)
            {
              var check = moment(date).format('YYYY-MM-DD');
              var today = moment(new Date).format('YYYY-MM-DD');
              if(check < today)
              {
                alert("You can't select previous Date");
              }
              else{
                $('#event-date').val(check);
              }
            },
            events:booking
          });
        }

      })
     // var calendar = $('#calendar').fullCalendar({
     //  editable:true,
     //  header:{
     //   left:'prev,next today',
     //   center:'title',
     //   right:'month,agendaWeek,agendaDay'
     //  },
     //  events: 'load.php',
     //  selectable:true,
     //  selectHelper:true,
     //  select: function(start, end, allDay)
     //  {
     //   var title = prompt("Enter Event Title");
     //   if(title)
     //   {
     //    var start = $.fullCalendar.formatDate(start, "Y-MM-DD HH:mm:ss");
     //    var end = $.fullCalendar.formatDate(end, "Y-MM-DD HH:mm:ss");
     //    $.ajax({
     //     url:"insert.php",
     //     type:"POST",
     //     data:{title:title, start:start, end:end},
     //     success:function()
     //     {
     //      calendar.fullCalendar('refetchEvents');
     //      alert("Added Successfully");
     //     }
     //    })
     //   }
     //  },
     //  editable:true,
     //  eventResize:function(event)
     //  {
     //   var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD HH:mm:ss");
     //   var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD HH:mm:ss");
     //   var title = event.title;
     //   var id = event.id;
     //   $.ajax({
     //    url:"update.php",
     //    type:"POST",
     //    data:{title:title, start:start, end:end, id:id},
     //    success:function(){
     //     calendar.fullCalendar('refetchEvents');
     //     alert('Event Update');
     //    }
     //   })
     //  },

     //  eventDrop:function(event)
     //  {
     //   var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD HH:mm:ss");
     //   var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD HH:mm:ss");
     //   var title = event.title;
     //   var id = event.id;
     //   $.ajax({
     //    url:"update.php",
     //    type:"POST",
     //    data:{title:title, start:start, end:end, id:id},
     //    success:function()
     //    {
     //     calendar.fullCalendar('refetchEvents');
     //     alert("Event Updated");
     //    }
     //   });
     //  },

     //  eventClick:function(event)
     //  {
     //   if(confirm("Are you sure you want to remove it?"))
     //   {
     //    var id = event.id;
     //    $.ajax({
     //     url:"delete.php",
     //     type:"POST",
     //     data:{id:id},
     //     success:function()
     //     {
     //      calendar.fullCalendar('refetchEvents');
     //      alert("Event Removed");
     //     }
     //    })
     //   }
     //  },

     // });
      // $('.submit').click(function()
      // {
      //   if($('#event-date').val()=="")
      //   {
      //     alert("Hello");
      //     //$('.submit').prop('disabled',true);
      //   }
      // })
    });
   // function display_booking()
   // {
   //  var booking = new Array();
   //  $.ajax({
   //    url:'display_booking.php',
   //    dataType:'json',
   //    success:function(response)
   //    {
   //      var result = response.data;
   //      $.each(result,function(i,item){
   //        booking.push({
   //          booking_id:result[i].booking_id,
   //          booking_date:result[i].booking_date,
   //          booking_name:result[i].title,
   //          booking_color:result[i].color
   //        });
   //      })
   //      var c = $('#calendar').fullCalendar({
   //        defaultView:'month',
   //        timeZone:'local',
   //        editable:'true',
   //        selectable:'true',
   //        selectHelper:'true',
   //        select:function(data)
   //        {
   //          alert(data);
   //        }
   //      })
   //    }
   //  })
   // }
  </script>