<?php require_once("../../resources/config.php");   ?>
<?php include(TEMPLATE_BACK.DS."header.php");?>
<?php
    if(isset($_SESSION['username']) && $_SESSION['role'] == 1)
    {
        if(isset($_GET['id']))
        {
            $q = query("DELETE FROM booking WHERE booking_id='{$_GET['id']}'");
            confirm($q);
            $query = query("DELETE FROM booking_line WHERE booking_id='{$_GET['id']}'");
            confirm($query);
            set_message("Booking Successfully removed");
            redirect("index.php?view_booking");
        }
?>

<?php include(TEMPLATE_BACK.DS."footer.php");
} else{
    redirect("../../public/login.php");
}
?>