<?php require_once("../../resources/config.php");   ?>
<?php include(TEMPLATE_BACK.DS."header.php");?>
<?php
    if(!isset($_SESSION['username']) && isset($_SESSION['role']) != 1)
    {
        redirect("../../public/login.php");
    }
?>
<?php
    if(isset($_GET['id']))
    {
        $query = query("DELETE FROM marriage_hall_line WHERE marriage_hall_line_id='{$_GET['id']}'");
        confirm($query);
        set_message("Hall Successfully Deleted");
        redirect("index.php?view_hall_detail");
    }
?>
<?php include(TEMPLATE_BACK.DS."footer.php");?>