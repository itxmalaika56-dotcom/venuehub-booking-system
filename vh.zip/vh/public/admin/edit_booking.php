<?php require_once("../../resources/config.php");   ?>
<?php include(TEMPLATE_BACK.DS."header.php");?>
<?php
    if(isset($_SESSION['username']) && $_SESSION['role'] == 1)
    {  
?>
<?php
    if(isset($_GET['id']))
    {
        $method = "";
        $amount = 0;
        $transaction_id = "";
        $receipt = "";
        $date = "";
        $payment_status = "";
        $qry = query("SELECT * FROM payment WHERE booking_id = '{$_GET['id']}'");
        confirm($qry);
        while($row = fetch_array($qry))
            {
                $method = $row['payment_method'];
                $amount = $row['amount'];
                $transaction_id = $row['transaction_id'];
                $receipt = $row['payment_receipt'];
                $date = $row['payment_date'];
                $payment_status = $row['payment_status'];
            }
        $query = query("SELECT * FROM view_booking WHERE booking_id = '{$_GET['id']}'");
        confirm($query);
        while($row = fetch_array($query))
        {
            $booking_id = $row['booking_id'];
            $booking_date = $row['booking_date'];
            $booking_shift = $row['booking_shift'];
            if($row['booking_shift'] == 0)
            {
                $shift = "Noon";
            }
            else
            {
                $shift = "Evening";
            }
            $charges = $row['booking_bill'];
            $reserved_payment = 0.1 * $row['booking_bill'];
            $services = $row['service_description'];
            $marriage_hall_id = $row['marriage_hall_id'];
            $hall_id = $row['marriage_hall_line_id'];
            $hall_name = $row['marriage_hall_line_name'];
            $user_id = $row['user_id'];
            $first_name = $row['first_name'];
            $last_name = $row['last_name'];
            $phone = $row['phone'];
            $address = $row['address'];
            $guests = $row['guests'];
            $discount = $row['booking_discount'];
            $status = $row['status'];
        }
    }
?>
<div id="page-wrapper">
    <div class="container-fluid">
        <h3 class="bg-success text-center"><?php display_message();?></h3>
        <h3 class="text-center">Edit Booking</h3>
        <form method="post">
            <div class="form-row">
                <div class="form-group col-md-6">
                  <label for="inputEmail4">Name</label>
                  <input type="text" class="form-control" id="inputEmail4" name="name" placeholder="Name" value="<?php echo $first_name; ?>&nbsp;<?php echo $last_name; ?>">
                </div>
                <div class="form-group col-md-6">
                  <label for="inputPassword4">Phone # </label>
                  <input type="text" class="form-control" id="inputPassword4" name="phone" placeholder="Phone" value="<?php echo $phone; ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                  <label for="inputEmail4">Booking Date</label>
                  <input type="text" class="form-control" id="inputEmail4" name="booking_date" placeholder="Booking Date" value="<?php echo $booking_date; ?>" readonly>
                </div>
                <div class="form-group col-md-6">
                  <label for="inputPassword4">Shift</label>
                  <input type="text" class="form-control" id="inputPassword4" name="shift" placeholder="shift" value="<?php echo $shift; ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                  <label for="inputEmail4">Hall Name</label>
                  <input type="text" class="form-control" id="inputEmail4" name="hall-name" placeholder="Hall Name" value="<?php echo $hall_name; ?>">
                </div>
                <div class="form-group col-md-6">
                  <label for="inputPassword4">Guests</label>
                  <input type="text" class="form-control" id="inputPassword4" name="guests" placeholder="Phone" value="<?php echo $guests; ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="inputAddress">Services</label>
                    <textarea type="text" class="form-control" id="inputAddress" name="services" placeholder="services"><?php echo $services; ?></textarea>
                </div>
                <div class="form-group col-md-6">
                    <label for="inputAddress">Address</label>
                    <textarea type="text" class="form-control" id="inputAddress" name="address" placeholder="1234 Main St" readonly><?php echo $address; ?></textarea>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-4">
                  <label for="inputEmail4">Bill</label>
                  <input type="text" class="form-control"  name="bill" value="<?php echo $charges;?>" readonly>
                </div>
                <div class="form-group col-md-4">
                  <label for="inputEmail4">Reserved Payment</label>
                  <input type="text" class="form-control"  name="reserved_payment" value="<?php echo $reserved_payment;?>" readonly>
                </div>
                <div class="form-group col-md-4">
                  <label for="inputEmail4">Discount</label>
                  <input type="text" class="form-control"  name="discount" value="<?php echo $discount; ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-4">
                  <label for="inputEmail4">Transaction_id</label>
                  <input type="text" class="form-control"  name="transaction_id" value="<?php echo $transaction_id; ?>" readonly>
                </div>
                <div class="form-group col-md-4">
                  <label for="inputEmail4">Method</label>
                  <input type="text" class="form-control"  name="payment_method" value="<?php echo $method;?>">
                </div>
                <div class="form-group col-md-4">
                  <label for="inputEmail4">Payment Date</label>
                  <input type="text" class="form-control"  name="date" value="<?php echo $date; ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                  <label for="inputEmail4">Paid Amount</label>
                  <input type="text" class="form-control" id="inputEmail4" name="paid" placeholder="" value="<?php echo $amount ?>" readonly>
                </div>
                <div class="form-group col-md-6">
                  <label for="inputPassword4">Receipt</label>
                  <img src="../../resources/receipt/<?php echo $receipt; ?>" style="height:250px; width:200px;" />
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                  <label for="inputEmail4">Remaining</label>
                  <input type="text" class="form-control" id="inputEmail4" name="remaining" placeholder="Remaining" value="<?php echo $charges-$discount-$amount; ?>" readonly>
                </div>
                <div class="form-group col-md-6">
                  <label for="inputPassword4">Status</label>
                  <select id="inputState" class="form-control" name="status">
                    <option <?php echo ($status == 0) ? "selected" : "" ?> value="0">Inactive</option>
                    <option <?php echo ($status == 1) ? "selected" : "" ?> value="1">Active</option>
                  </select>
                </div>
            </div>
            <div class="form-group col-md-2">
                <button type="submit" class="btn btn-primary" name="update">Update</button>
            </div>
        </form>
    </div>
</div>

<?php
    if(isset($_POST['update']))
    {
        $sql = query("UPDATE booking SET status ='{$_POST['status']}', booking_discount = '{$_POST['discount']}' WHERE booking_id='{$_GET['id']}'");
        confirm($sql);
        set_message("Booking has Successfully Updated");
        redirect("index.php?view_booking");
    }
    
?>

<?php include(TEMPLATE_BACK.DS."footer.php");
} else{
    redirect("../../public/login.php");
}
?>