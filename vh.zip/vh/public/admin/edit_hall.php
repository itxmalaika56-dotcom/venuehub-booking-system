<?php require_once("../../resources/config.php");   ?>
<?php include(TEMPLATE_BACK.DS."header.php");?>
<?php
    if(isset($_SESSION['username']) && $_SESSION['role'] == 1)
    {
		if(isset($_GET['id']))
		{

			$query = query("SELECT * FROM marriage_hall_line WHERE marriage_hall_line_id=".escape_string($_GET['id'])."");
			confirm($query);
			while($row = fetch_array($query))
			{
				$name = $row['marriage_hall_line_name'];
				$floor = $row['floor'];
				$capacity = $row['capacity'];
			}
		}
?>
<div id="page-wrapper">
    <div class="container-fluid">
    	<h3>Update Hall Detail</h3>
		<div class="row">
			<div class="col-md-4">
				<form method="post">
					<label>Hall Name</label>
					<input type="text" class="form-control" name="hall-name" value="<?php echo $name; ?>">
					<label>Hall Floor</label>
					<input type="text" class="form-control" name="floor" value="<?php echo $floor; ?>">
					<label>Hall Capacity</label>
					<input type="text" class="form-control" name="capacity" value="<?php echo $capacity; ?>"><br>
					<input type="submit" name="update" value="Update" class="btn btn-primary">
				</form>
			</div>
		</div>
	</div>
</div>
<?php
if(isset($_POST['update']))
	{
	$sql = query("UPDATE marriage_hall_line SET marriage_hall_line_name ='{$_POST['hall-name']}',floor ='{$_POST['floor']}',capacity ='{$_POST['capacity']}' WHERE marriage_hall_line_id='{$_GET['id']}'");
	confirm($sql);
	set_message("Hall Successfully Updated");
	redirect("index.php?view_hall_detail");
	}
?>
<?php include(TEMPLATE_BACK.DS."footer.php");
} else{
    redirect("../../public/login.php");
}
?>
