<?php require_once("../../resources/config.php");   ?>
<?php include(TEMPLATE_BACK.DS."header.php");?>

<?php
    if(isset($_SESSION['username']) && $_SESSION['role'] == 1)
    {
        
    
?>
        <div id="page-wrapper">
            <div class="container-fluid">
                <h3 class="bg-success text-center"><?php display_message(); ?></h3>
            <?php 

                if($_SERVER['REQUEST_URI'] == "/vh/public/admin/" || $_SERVER['REQUEST_URI'] == "/vh/public/admin/index.php")
                {
                    include(TEMPLATE_BACK.DS."admin_content.php");
                }
                if(isset($_GET['add_marriage_hall'])){

                    include(TEMPLATE_BACK . "/add_marriage_hall.php");

                }
                if(isset($_GET['add_hall_detail'])){

                    include(TEMPLATE_BACK . "/add_hall_detail.php");
                }
                if(isset($_GET['view_hall_detail'])){

                    include(TEMPLATE_BACK . "/view_hall_detail.php");
                }
                if(isset($_GET['view_booking'])){

                    include(TEMPLATE_BACK . "/view_booking.php");
                }
                if(isset($_GET['add_services'])){

                    include(TEMPLATE_BACK . "/add_services.php");
                }

            ?>
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->
<?php include(TEMPLATE_BACK.DS."footer.php");
} else{
    redirect("../../public/login.php");
}
?>

 