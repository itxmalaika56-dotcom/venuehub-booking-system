<?php require_once("../resources/config.php");   ?>
<?php include(TEMPLATE_FRONT.DS."header.php");?>
<table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
        <tr>
            <th>Booking #</th>
            <th>Hall Name</th>
            <th>Booker</th>
            <th>Phone #</th>
            <th>Date</th>
            <th>Shift</th>
            <th>Status</th>
            <th>Payment</th>
        </tr>
    </thead>
    <tbody>
        <?php booking_history(); ?>
    </tbody>
    
</table>
<script src="js/jquery.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript">
        new DataTable('#example');
    </script>








<?php include(TEMPLATE_FRONT.DS."footer.php");?>