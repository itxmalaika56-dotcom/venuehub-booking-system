<?php require_once("../resources/config.php");   ?>
<?php
	if(isset($_POST['username']))
	{
		$username = escape_string($_POST['username']);
		$query = query("SELECT * FROM users WHERE username = '{$username}'");
		confirm($query);
		echo mysqli_num_rows($query);
	}
	if(isset($_POST['email']))
	{
		$email = escape_string($_POST['email']);
		$query = query("SELECT * FROM users WHERE email = '{$email}'");
		confirm($query);
		echo mysqli_num_rows($query);
	}
	if(isset($_POST['phone']))
	{
		$phone = escape_string($_POST['phone']);
		$query = query("SELECT * FROM users WHERE phone = '{$phone}'");
		confirm($query);
		echo mysqli_num_rows($query);
	}
?>