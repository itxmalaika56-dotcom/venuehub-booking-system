<?php require_once("../resources/config.php");   ?>
<?php include(TEMPLATE_FRONT.DS."header.php");?>
<?php
  if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
    redirect("login.php");
  }
?>
<?php
include("save_booking.php"); 
$service_id="";
$service_line_id="";
if(isset($_POST['submit']))
    {
      $marriage_hall_id = $_POST['marriage-hall'];
      $hall_id = $_POST['hall'];
      $date = $_POST['event-date'];
      $event_shift = $_POST['event-shift'];
      if($event_shift==0)
      {
        $shift = "Noon: 12 PM to 5 PM";
      }
      else
      {
        $shift = "Evening: 6 PM to 10 PM";
      }
      $guests = $_POST['event-guest'];
      $deal = $_POST['deal'];
      $query = query("SELECT * FROM view_service WHERE service_line_id='{$deal}'");
      confirm($query);
      while($row = fetch_array($query))
      {
        $per_unit_price = $row['service_per_unit_charges'];
        $service_id = $row['service_id'];
        $service_line_id = $row['service_line_id'];
      }
      $total_bill = $per_unit_price*$guests;
      if($deal!=0)
      { ?>
        <table class="table table-striped table-bordered">
          <thead>
            <tr>
              <th>Booking Date</th>
              <th>Shift</th>
              <th>Guests</th>
              <th>Deal</th>
              <th>Price Per Unit</th>
              <th>Total Bill</th>
            </tr>
          </thead>
          <tbody>
              <tr>
                <td><?php echo $date; ?></td>
                <td><?php echo $shift; ?></td>
                <td><?php echo $guests; ?></td>
                <td><?php echo $deal; ?></td>
                <td><?php echo $per_unit_price; ?></td>
                <td><?php echo $total_bill; ?></td>
              </tr>
          </tbody>
          <tfooter>
            <tr>
              <th>Booking Date</th>
              <th>Shift</th>
              <th>Guests</th>
              <th>Deal</th>
              <th>Price Per Unit</th>
              <th>Total Bill</th>
            </tr>
          </tfooter>
        </table>        
      <?php }
  }
?>
<form method="post" id="booking-form">
  <input type="hidden" name="save_booking_data" id="save_booking_data">
  <input type="hidden" name="user-id" value="<?php echo $_SESSION['user_id']; ?>">
  <input type="hidden" name="marriage-hall-id" value="<?php echo $marriage_hall_id; ?>">
  <input type="hidden" name="hall-id" value="<?php echo $hall_id; ?>">
  <input type="hidden" name="event-date" value="<?php echo $date; ?>">
  <input type="hidden" name="event-guests" value="<?php echo $guests; ?>">
  <input type="hidden" name="event-shift" value="<?php echo $event_shift; ?>">
  <input type="hidden" name="event-bill" value="<?php echo $total_bill; ?>">
  <input type="hidden" name="service_id" id="service_id" value="<?php echo $service_id; ?>">
  <input type="hidden" name="service_line_id" id="service_line_id" value="<?php echo $service_line_id; ?>">
  <input type="submit" name="booking" class="btn btn-primary" onclick="return save_booking()">
</form>

<?php include(TEMPLATE_FRONT.DS."footer.php");?>
<script type="text/javascript">
  
  function save_booking()
  {
    var arry = [];
    var service_id = $('#service_id').val();
    var service_line_id = $('#service_line_id').val();
    var save_booking_line = {
      id: service_id,
      line_id: service_line_id
    };
    arry.push(save_booking_line);
    
    var str_json = JSON.stringify(arry);
    $('#save_booking_data').val(str_json);
    //alert($('#save_booking_data').val());
    return true;
  }
</script>