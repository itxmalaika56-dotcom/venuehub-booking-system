<?php require_once("../resources/config.php");   ?>
<?php
$query = query("SELECT * FROM booking WHERE marriage_hall_line_id = '{$_SESSION['hall_id']}' AND status=1");
confirm($query);
$count = mysqli_num_rows($query);
if($count>0)
{
	$data_arr = array();
	$i=1;
	while ($row = fetch_array($query)) {
		if($row['booking_shift'] == 0)
		{
			$shift = "Noon (12 PM to 5 PM)";
		}
		else
		{
			$shift = "Evening (6 PM to 10 PM)";
		}
		$data_arr[$i]['booking_id'] = $row['booking_id'];
		$data_arr[$i]['booking_date'] = $row['booking_date'];
		$data_arr[$i]['title']='Booked('.$shift.')';
		//$data_arr[$i]['title']='Booked' <br> .$shift;
		$data_arr[$i]['color']='green';
		$data_arr[$i]['textColor']='#ffffff';
		$i++;
	}
	$data = array(
		'status'=> true,
		'msg' => 'successfully',
		'data' => $data_arr
	);
}
else
{
	$data = array(
		'status'=> false,
		'msg' => 'error'
	);
}
echo json_encode($data);



	?>