<?php require_once("../resources/config.php");   ?>
<?php include(TEMPLATE_FRONT.DS."header.php");?>
<?php
	if(isset($_GET['hall_id'])){
		$query = query("SELECT * FROM marriage_hall_line WHERE marriage_hall_line_id='{$_GET['hall_id']}'");
		confirm($query);
		while ($row = fetch_array($query)) {
			//$_SESSION['capacity'] = $row['capacity'];
      $capacity = $row['capacity'];
		}
	}
?>
 
  <h2 align="center">Add Booking Detail</h2>
  <br />
  <div class="container">
  	<div class="row">
  		<div class="col-md-5">
  			<div id="calendar"></div>
  		</div>
  		<div class="col-md-7">
  			<label>Booking Date</label>
  			<input type="text" name="event-date" id="event-date" class="form-control" readonly required>
  			<label>No. of Guest</label>
  			<input type="text" name="event-date" id="guests" class="form-control" required>
        <label>Menu:</label>
        <?php deal_service(); ?>

  		</div>
  	</div>
    <div class="row">
      
    </div>
  </div>
  <?php include(TEMPLATE_FRONT.DS."footer.php");?>
<script>
   
    $(document).ready(function() {
      $("#guests").blur(function() {
      var guest = $(this).val();
      var capacity = '<?php echo $capacity; ?>';
      if(guest>capacity)
      {
        alert("You can't add more than capacity");
      }
      else
      {
        capacity = $('$guests').val();
      }
    });
      var calendar = $('#calendar').fullCalendar({
        defaultView: 'month',
       timeZone: 'local',
        editable: true,
          selectable: true,
      selectHelper: true,
      select: function(date)
      {
        var check = moment(date).format('YYYY-MM-DD');
        var today = moment(new Date).format('YYYY-MM-DD');
        if(check < today)
        {
          alert("You can't select previous Date");
        }
        else{
          $('#event-date').val(check);
        }
        //$('#event-date').val(moment(date).format('YYYY-MM-DD'));
      }
      });
     // var calendar = $('#calendar').fullCalendar({
     //  editable:true,
     //  header:{
     //   left:'prev,next today',
     //   center:'title',
     //   right:'month,agendaWeek,agendaDay'
     //  },
     //  events: 'load.php',
     //  selectable:true,
     //  selectHelper:true,
     //  select: function(start, end, allDay)
     //  {
     //   var title = prompt("Enter Event Title");
     //   if(title)
     //   {
     //    var start = $.fullCalendar.formatDate(start, "Y-MM-DD HH:mm:ss");
     //    var end = $.fullCalendar.formatDate(end, "Y-MM-DD HH:mm:ss");
     //    $.ajax({
     //     url:"insert.php",
     //     type:"POST",
     //     data:{title:title, start:start, end:end},
     //     success:function()
     //     {
     //      calendar.fullCalendar('refetchEvents');
     //      alert("Added Successfully");
     //     }
     //    })
     //   }
     //  },
     //  editable:true,
     //  eventResize:function(event)
     //  {
     //   var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD HH:mm:ss");
     //   var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD HH:mm:ss");
     //   var title = event.title;
     //   var id = event.id;
     //   $.ajax({
     //    url:"update.php",
     //    type:"POST",
     //    data:{title:title, start:start, end:end, id:id},
     //    success:function(){
     //     calendar.fullCalendar('refetchEvents');
     //     alert('Event Update');
     //    }
     //   })
     //  },

     //  eventDrop:function(event)
     //  {
     //   var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD HH:mm:ss");
     //   var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD HH:mm:ss");
     //   var title = event.title;
     //   var id = event.id;
     //   $.ajax({
     //    url:"update.php",
     //    type:"POST",
     //    data:{title:title, start:start, end:end, id:id},
     //    success:function()
     //    {
     //     calendar.fullCalendar('refetchEvents');
     //     alert("Event Updated");
     //    }
     //   });
     //  },

     //  eventClick:function(event)
     //  {
     //   if(confirm("Are you sure you want to remove it?"))
     //   {
     //    var id = event.id;
     //    $.ajax({
     //     url:"delete.php",
     //     type:"POST",
     //     data:{id:id},
     //     success:function()
     //     {
     //      calendar.fullCalendar('refetchEvents');
     //      alert("Event Removed");
     //     }
     //    })
     //   }
     //  },

     // });
    });
   
  </script>