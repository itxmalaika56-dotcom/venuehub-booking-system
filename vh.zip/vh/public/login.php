<?php require_once("../resources/config.php");   ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
  <?php include("../resources/templates/front/header_links.php");?>
  <style type="text/css">
      <style type="text/css">
    @media (min-width: 1025px)
    {
      .h-custom
      {
        height: 100vh !important;
      }
    }
    .signup:hover
    {
      color: red;
    }
  </style>
  </style>
</head>
<body>
  <section class="" style="background-color: #8fc4b7;">
    <div class="container py-5 h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-lg-8 col-xl-6">
          <div class="card rounded-3">
            <div style="display: flex; justify-content: center;">
              <img src="img/logo.jpeg"
               style="border-top-left-radius: .3rem; border-top-right-radius: .3rem; height: 150px; width: 150px;"
              alt="Sample photo">
            </div>
            
            <div class="card-body p-4 p-md-5">
              <h3 class="bg-warning text-center"><?php display_message(); ?></h3>
              <h3 class="mb-4 pb-2 pb-md-0 mb-md-5 px-md-2">Login</h3>
              <form class="px-md-2" action="" method="post">
                <!-- <?php log_in();?> -->
                <div class="form-outline mb-4">
                  <input type="text" id="username-email" class="form-control"  name="username-email" required/>
                  <label class="form-label" for="form3Example1q">Username/Email</label>
                </div>
                <div class="form-outline mb-4">
                  <input type="password" id="form3Example1q" class="form-control"  name="password" required/>
                  <label class="form-label" for="form3Example1q">Password</label>
                </div>
                <input type="submit" class="btn btn-success btn-lg mb-1" name="login" id="login" value="Login" /><br>
                <a href="sign_up.php" class="signup">Don't Have,Create an account</a>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <?php include("../resources/templates/front/footer_links.php");?>
</body>
</html>