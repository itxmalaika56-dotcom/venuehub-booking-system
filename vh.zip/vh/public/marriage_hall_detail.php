<?php require_once("../resources/config.php");?>
<?php include(TEMPLATE_FRONT.DS."header.php");?>
<?php
	$query = query("SELECT * FROM marriage_hall WHERE marriage_hall_id = '{$_GET['id']}'");
	confirm($query);
	while ($row = fetch_array($query)) {
		$name = $row['marriage_hall_name'];
		$image = $row['marriage_hall_image'];
		$phone = $row['marriage_hall_phone'];
		$email = $row['marriage_hall_email'];
		$city = $row['marriage_hall_city'];
		$zip = $row['marriage_hall_zip_code'];
		$address = $row['marriage_hall_address'];
	}
?>
<style type="text/css">
	body{
    background-color: #edf1f5;
    margin-top:20px;
}
.card {
    margin-bottom: 30px;
}
.card {
    position: relative;
    display: flex;
    flex-direction: column;
    min-width: 0;
    word-wrap: break-word;
    background-color: #fff;
    background-clip: border-box;
    border: 0 solid transparent;
    border-radius: 0;
}
.card .card-subtitle {
    font-weight: 300;
    margin-bottom: 10px;
    color: #8898aa;
}
.table-product.table-striped tbody tr:nth-of-type(odd) {
    background-color: #f3f8fa!important
}
.table-product td{
    border-top: 0px solid #dee2e6 !important;
    color: #728299!important;
}
</style>

<div class="container">
    <div class="card">
        <div class="card-body">
            <h3 class="card-title"><?php echo $name;?></h3>
            <!-- <h6 class="card-subtitle">globe type chair for rest</h6> -->
            <div class="row">
                <div class="col-lg-5 col-md-5 col-sm-6">
                    <div class="white-box text-center"><img src="../resources/uploads/<?php echo $image; ?>" class="img-responsive" height="400" width="700"></div>
                </div>
                <div class="col-lg-7 col-md-7 col-sm-6">
                    <h4 class="box-title mt-5">Contact Detail</h4>
                    <table class="table table-bordered table-striped table-product">
                    	<tr>
                    		<th>Phone</th>
                    		<td><?php echo $phone; ?></td>
                    	</tr>
                    	<tr>
                    		<th>Email</th>
                    		<td><?php echo $email; ?></td>
                    	</tr>
                    	<tr>
                    		<th>City</th>
                    		<td><?php echo $city; ?></td>
                    	</tr>
                    	<tr>
                    		<th>Zip</th>
                    		<td><?php echo $zip; ?></td>
                    	</tr>
                    	<tr>
                    		<th>Address</th>
                    		<td><?php echo $address; ?></td>
                    	</tr>
                    </table>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <h3 class="box-title mt-5">Hall Detail</h3>
                    <div class="table-responsive">
                        <table class="table table-striped table-product">
                        	<thead>
                        		<tr>
                        			<th>Hall Name</th>
                        			<th>Floor</th>
                        			<th>Guest Capacity</th>
                        			<th></th>
                        		</tr>
                        	</thead>
                            <tbody>
                                <?php hall_detail();?>
                            </tbody>
                            
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include(TEMPLATE_FRONT.DS."footer.php");?>