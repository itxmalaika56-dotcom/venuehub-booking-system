<?php require_once("../resources/config.php");?>
<?php include(TEMPLATE_FRONT.DS."header.php");?>      
<?php
    if(!isset($_SESSION['username']) && $_SESSION['role'] == 2)
    { 
        redirect("login.php");
    }
?>

<div class="container" style="margin-top:50px; margin-bottom:50px;">

    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="card shadow">
                <div class="card-header">
                    <h3 class="text-center">Payment</h3>
                </div>

                <div class="card-body">

                    <form action=""
                          method="POST"
                          enctype="multipart/form-data">
                        <?php payment(); ?>

                         <!-- Payment Method -->
                        <div class="form-group mb-3">
                            <label for="payment_method">
                                <strong>Payment Method</strong>
                            </label>

                            <select name="payment_method" class="form-control" required>
                                <option value="">Select any option</option>
                                <option value="easypaisa">Easypaisa</option>
                                <option value="jazzcash">Jazzcash</option>
                                <option value="bank">Bank Account</option>
                            </select>
                        </div>

                        <!-- Transaction ID -->
                        <div class="form-group mb-3">
                            <label for="transaction_id">
                                <strong>Transaction ID</strong>
                            </label>

                            <input
                                type="text"
                                name="transaction_id"
                                id="transaction_id"
                                class="form-control"
                                placeholder="Enter Transaction ID"
                                required>
                        </div>


                        <!-- Amount -->
                        <div class="form-group mb-3">
                            <label for="amount">
                                <strong>Amount</strong>
                            </label>

                            <input
                                type="number"
                                name="amount"
                                id="amount"
                                class="form-control"
                                placeholder="Enter Amount"
                                min="1"
                                step="0.01"
                                required>
                        </div>


                        <!-- Receipt Upload -->
                        <div class="form-group mb-3">
                            <label for="receipt">
                                <strong>Payment Receipt</strong>
                            </label>

                            <input
                                type="file"
                                name="receipt"
                                id="receipt"
                                class="form-control"
                                accept="image/*,.pdf"
                                required>

                            <small class="text-muted">
                                Upload your payment screenshot or receipt
                                (JPG, PNG or PDF)
                            </small>
                        </div>


                        <!-- Submit Payment -->
                        <div class="text-center">
                            <button
                                type="submit"
                                name="submit_payment"
                                class="btn btn-primary">
                                Submit Payment
                            </button>
                        </div>

                    </form>

                    <hr>

                    <!-- Print Receipt -->
                    <!-- <div class="text-center">
                        <button
                            type="button"
                            onclick="window.print()"
                            class="btn btn-success">
                            <i class="fa fa-print"></i>
                            Print Receipt
                        </button>
                    </div> -->

                </div>
            </div>

        </div>
    </div>

</div>


 <?php include(TEMPLATE_FRONT.DS."footer.php");?>