<?php require_once("../resources/config.php");   ?>
<?php
	if(isset($_POST['booking']))
	{
		$booking_date = $_POST['event-date'];
		$marriage_hall_id = $_POST['marriage-hall-id'];
		$hall_id = $_POST['hall-id'];
		$guests = $_POST['event-guests'];
		$shift = $_POST['event-shift'];
		$bill = $_POST['event-bill'];
		$user_id = $_POST['user-id'];
		$sql = query("INSERT INTO booking(marriage_hall_id,marriage_hall_line_id,user_id,booking_date,guests,booking_shift,booking_bill) VALUES('{$marriage_hall_id}','{$hall_id}','{$user_id}','{$booking_date}','{$guests}','{$shift}','{$bill}')");
		confirm($sql);
		$last_id = last_id();
		$str_json = $_POST['save_booking_data'];
		$booking_line_decode = json_decode($str_json,true);
		foreach ($booking_line_decode as $row) {
			$query = query("INSERT INTO booking_line(booking_id,service_id,service_line_id) VALUES('$last_id','".$row['id']."','".$row['line_id']."')");
			confirm($query);
			redirect("thank_you.php");
			set_message("Bookig Successfully Added but is pending with Booking # ".$last_id);
		}
	}
?>