<?php require_once("../resources/config.php");   ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
  <?php include("../resources/templates/front/header_links.php");?>
  <style type="text/css">
    @media (min-width: 1025px)
    {
      .h-custom
      {
        height: 100vh !important;
      }
    }
    .signin:hover
    {
      color: red;
    }
  </style>
</head>
<body>
  <section class="" style="background-color: #8fc4b7;">
    <div class="container py-5 h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-lg-8 col-xl-6">
          <div class="card rounded-3">
            <div style="display: flex; justify-content: center;">
              <img src="img/logo.jpeg"
               style="border-top-left-radius: .3rem; border-top-right-radius: .3rem; height: 150px; width: 150px;"
              alt="Sample photo">
            </div>
            <div class="card-body p-4 p-md-5">
              <h3 class="bg-warning text-center"><?php display_message(); ?></h3>
              <h3 class="mb-4 pb-2 pb-md-0 mb-md-5 px-md-2">Registration Info</h3>
              <form class="px-md-2" action="" method="post">
                <?php sign_up();?>
                <div class="row">
                  <div class="col-md-6 mb-4">
                  <input type="text" id="form3Example1q" class="form-control" name="first-name" required pattern="[A-Za-z ]+" title="First Name must contain letters and spaces only." />
                  <label class="form-label" for="form3Example1q">First Name</label>
                
                  </div>
                  <div class="col-md-6 mb-4">
                   <input type="text" id="form3Example1q" class="form-control" name="last-name" required pattern="[A-Za-z ]+" title="Last Name must contain letters and spaces only."/>
                  <label class="form-label" for="form3Example1q">Last Name</label>
                  </div>
                  
                </div>
                <div class="form-outline mb-4">
                  <input type="text" id="email" class="form-control" name="email" required pattern="[a-zA-Z0-9._%+-]+@gmail\.com" title="Please enter a valid Gmail address."/>
                  <label class="form-label" for="form3Example1q">Email</label><br>
                  <span id="email-availaibility"></span>
                </div>
                <div class="form-outline mb-4">
                  <input type="text" id="username" class="form-control"  name="username"/>
                  <label class="form-label" for="form3Example1q">Username</label><br>
                  <span id="username-availaibility"></span>
                </div>
                <div class="form-outline mb-4">
                  <input type="password" id="form3Example1q" class="form-control" name="password" required minlength="6" title="Password must be at least 6 characters long."/>
                  <label class="form-label" for="form3Example1q">Password</label>
                </div>
                <div class="form-outline mb-4">
                <input type="text" id="phone" class="form-control" name="phone" required pattern="[0-9]+" inputmode="numeric" title="Phone number must contain numbers only."/>
                  <label class="form-label" for="form3Example1q">Phone:</label><br>
                  <span id="phone-availaibility"></span>
                </div>
                <div class="form-outline mb-4">
                  <textarea type="text" id="form3Example1q" class="form-control"  name="address" required></textarea>
                  <label class="form-label" for="form3Example1q">Address</label>
                </div>

                <!-- <div class="row">
                  <div class="col-md-6 mb-4">

                    <div class="form-outline datepicker">
                      <input type="text" class="form-control" id="exampleDatepicker1" />
                      <label for="exampleDatepicker1" class="form-label">Select a date</label>
                    </div>

                  </div>
                  <div class="col-md-6 mb-4">

                    <select class="select form-control">
                      <option value="1" disabled>Gender</option>
                      <option value="2">Female</option>
                      <option value="3">Male</option>
                      <option value="4">Other</option>
                    </select>

                  </div>
                </div> -->
                <div class="row">
                  <div class="col-md-6 mb-4">

                  <select class="select form-control" name="role" id="role" required>
                    <option value="">Select Any One</option>
                    <option value="1">Hotel Admin</option>
                    <option value="2">Guest</option>
                  </select>

                </div>
                </div>
                <input type="text" name="status" id="status" value="" hidden>
                

                <!-- <div class="row mb-4 pb-2 pb-md-0 mb-md-5">
                  <div class="col-md-6">

                    <div class="form-outline">
                      <input type="text" id="form3Example1w" class="form-control" />
                      <label class="form-label" for="form3Example1w">Registration code</label>
                    </div>

                  </div>
                </div> -->
                <input type="submit" class="btn btn-success btn-lg mb-1" name="sign-up" id="sign-up" value="Register" /><br>
                <a href="login.php" class="signin">Already Have an account</a>
                <!-- <button type="submit" id="sign-up" class="btn btn-success btn-lg mb-1" name="sign-up">Submit</button> -->

              </form>

            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <?php include("../resources/templates/front/footer_links.php");?>
  <script type="text/javascript">
    $(document).ready(function(){
      $('select').on('change', function() {
        if(this.value=='1')
        $('#status').val('0');
        else
          $('#status').val('1');
      });
      $('#username').blur(function(){
        var username = $(this).val();
        if(username!="")
        {
          $.ajax({
          url:'check_availaibility.php',
          method:"POST",
          data:{username:username},
          success:function(data)
          {
            if(data!='0')
            {
              $('#username-availaibility').html('<span class="text-danger">Username is not available </span>');
              $('#sign-up').attr("disabled",true);
            }
            else
            {
              $('#username-availaibility').html('<span class="text-success">Username is available</span>');
              $('#sign-up').attr("disabled",false);
            }
          }
        })
        }
      });
      $('#email').blur(function(){
        var email = $(this).val();
        if(email!="")
        {
          $.ajax({
          url:'check_availaibility.php',
          method:"POST",
          data:{email:email},
          success:function(data)
          {
            if(data!='0')
            {
              $('#email-availaibility').html('<span class="text-danger">This Email is already Registered </span>');
              $('#sign-up').attr("disabled",true);
            }
            else
            {
              $('#email-availaibility').html('<span class="text-success">Email is available</span>');
              $('#sign-up').attr("disabled",false);
            }
          }
        })
        }
      });
      $('#phone').blur(function(){
        var phone = $(this).val();
        if(phone!="")
        {
          $.ajax({
          url:'check_availaibility.php',
          method:"POST",
          data:{phone:phone},
          success:function(data)
          {
            if(data!='0')
            {
              $('#phone-availaibility').html('<span class="text-danger">This Number is already Registered </span>');
              $('#sign-up').attr("disabled",true);
            }
            else
            {
              $('#phone-availaibility').html('<span class="text-success">Number is available</span>');
              $('#sign-up').attr("disabled",false);
            }
          }
        })
        }
        
      });
    });
  </script>
</body>
</html>