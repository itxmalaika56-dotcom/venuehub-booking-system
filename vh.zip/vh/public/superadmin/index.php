<?php require_once("../../resources/config.php");   ?>
<?php include(TEMPLATE_BACK_ADMIN.DS."header.php");?>

<?php
    if($_SESSION['username'] == 'superadmin' && $_SESSION['role'] == 0)
    { ?>
        <div id="page-wrapper">
            <div class="container-fluid">

            <?php 

                if($_SERVER['REQUEST_URI'] == "/vh/public/superadmin/" || $_SERVER['REQUEST_URI'] == "/vh/public/superadmin/index.php")
                {
                    include(TEMPLATE_BACK_ADMIN.DS."admin_content.php");
                }
                if(isset($_GET['view_marriage_halls'])){

                    include(TEMPLATE_BACK_ADMIN . "/view_marriage_halls.php");

                }
                if(isset($_GET['marriage_hall_deatil'])){

                    include(TEMPLATE_BACK_ADMIN . "/marriage_hall_detail.php");

                }
                if(isset($_GET['view_hall_detail'])){

                    include(TEMPLATE_BACK_ADMIN . "/view_hall_detail.php");

                }
                if(isset($_GET['add_services'])){

                    include(TEMPLATE_BACK_ADMIN . "/add_services.php");

                }
                if(isset($_GET['view_users'])){

                    include(TEMPLATE_BACK_ADMIN . "/view_users.php");

                }

            ?>
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->
<?php include(TEMPLATE_BACK.DS."footer.php"); } else{
    redirect("../../public/login.php");
}?>

 