<?php require_once("../../resources/config.php");   ?>
<?php include(TEMPLATE_BACK_ADMIN.DS."header.php");?>
<?php
if($_SESSION['username'] == 'superadmin' && $_SESSION['role'] == 0)
{
	if(isset($_GET['id']))
	{
		$query = query("SELECT * FROM marriage_hall WHERE marriage_hall_id='{$_GET['id']}'");
		confirm($query);
		while($row = fetch_array($query))
		{
			$name = $row['marriage_hall_name'];
			$address = $row['marriage_hall_address'];
			$phone = $row['marriage_hall_phone'];
			$email = $row['marriage_hall_email'];
			$city = $row['marriage_hall_city'];
			$zip = $row['marriage_hall_zip_code'];
			$logo = $row['marriage_hall_logo'];
			$image = $row['marriage_hall_image'];
			$status = $row['marriage_hall_status'];
		}
	}
 ?>
<div id="page-wrapper">
    <div class="container-fluid">
    	<h3 class="bg-success text-center"><?php display_message(); ?></h3>
    	<h3 class="text-center">Detail View of Marriage Hall</h3>
		<table border="1" width="100%" class="table table-striped">
			<tr>
				<td>
					Logo
				</td>
				<td>
					<img src="../../resources/uploads/<?php echo $logo;?>" height="150" width="150">
				</td>
			</tr>
			<tr>
				<td>
					Name
				</td>
				<td>
					<?php echo $name; ?>
				</td>
			</tr>
			<tr>
				<td>
					Phone
				</td>
				<td>
					<?php echo $phone; ?>
				</td>
			</tr>
			<tr>
				<td>
					Email
				</td>
				<td>
					<?php echo $email; ?>
				</td>
			</tr>
			<tr>
				<td>
					City
				</td>
				<td>
					<?php echo $city; ?>
				</td>
			</tr>
			<tr>
				<td>
					Zip Code
				</td>
				<td>
					<?php echo $zip; ?>
				</td>
			</tr>
			<tr>
				<td>
					Image
				</td>
				<td>
					<img src="../../resources/uploads/<?php echo $image;?>" height="250" width="250">
				</td>
			</tr>
			<tr>
				<td>
					Status
				</td>
				<td>
					<form method="post">
						<select class="form-control" name="status" id="status" onchange="abc()">
							<option <?php echo ($status == 0) ? "selected" : "" ?> value="0">Inactive</option>
							<option <?php echo ($status == 1) ? "selected" : "" ?> value="1">Active</option>
						</select>
						<input type="submit" value="submit" name="submit" class="btn btn-success" />
					</form>
					
				</td>
			</tr>
		</table>
	</div>
</div>
<script type="text/javascript">
	function abc()
	{
		alert("Are You sure You want to change the status");
	}
	
</script>
<?php
	if(isset($_POST['submit']))
	{
		$sql = query("UPDATE marriage_hall SET marriage_hall_status ='{$_POST['status']}' WHERE marriage_hall_id='{$_GET['id']}'");
		confirm($sql);
		set_message("Marriage Hall Status Successfully Changed");
		redirect("marriage_hall_detail.php?id=".$_GET['id']);
	}

	include(TEMPLATE_BACK.DS."footer.php");
}
	else
	{
		redirect("../../public/login.php");
	}
?>