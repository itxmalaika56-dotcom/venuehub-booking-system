<?php require_once("../../resources/config.php");   ?>
<?php include(TEMPLATE_BACK_ADMIN.DS."header.php");?>
<?php
    if(!isset($_SESSION['username']) && isset($_SESSION['role']) != 1)
    {
        redirect("../../public/login.php");
    }
?>
<?php
    if(isset($_GET['id']))
    {
        $query = query("SELECT * FROM users WHERE user_id = ".escape_string($_GET['id'])."");
        confirm($query);
        while($row = fetch_array($query))
        {
            $first_name = $row['first_name'];
            $last_name = $row['last_name'];
            $username = $row['username'];
            $email = $row['email'];
            $password = $row['password'];
            $phone = $row['phone'];
            $address = $row['address'];
            $role = $row['role'];
            if($role == 1)
            {
                $result = "Hall Admin";
            }
            elseif($role == 2)
            {
                $result = "Guests";
            }
            $status = $row['status'];
        }
    }
?>
<div id="page-wrapper">
    <div class="container-fluid">
        <h3 class="bg-success text-center"><?php display_message();?></h3>
        <h3 class="text-center">Detail View of User</h3>
        <form method="post">
        <div class="form-row">
        <div class="form-group col-md-6">
          <label for="inputEmail4">First Name</label>
          <input type="text" class="form-control" id="inputEmail4" name="first-name" placeholder="First Name" value="<?php echo $first_name; ?>">
        </div>
        <div class="form-group col-md-6">
          <label for="inputPassword4">Last Name</label>
          <input type="text" class="form-control" id="inputPassword4" name="last-name" placeholder="Last Name" value="<?php echo $last_name; ?>">
        </div>
        </div>
        <div class="form-row">
        <div class="form-group col-md-6">
          <label for="inputEmail4">username</label>
          <input type="text" class="form-control" id="inputEmail4" name="username" placeholder="username" value="<?php echo $username; ?>" readonly>
        </div>
        <div class="form-group col-md-6">
          <label for="inputPassword4">Password</label>
          <input type="password" class="form-control" id="inputPassword4" name="password" placeholder="Password" value="<?php echo $password; ?>">
        </div>
        </div>
        <div class="form-row">
        <div class="form-group col-md-6">
          <label for="inputEmail4">Email</label>
          <input type="email" class="form-control" id="inputEmail4" name="email" placeholder="Email" value="<?php echo $email; ?>">
        </div>
        <div class="form-group col-md-6">
          <label for="inputPassword4">Phone</label>
          <input type="text" class="form-control" id="inputPassword4" name="phone" placeholder="Phone" value="<?php echo $phone; ?>">
        </div>
        </div>
        <div class="form-row">
        <div class="form-group col-md-6">
          <label for="inputEmail4">Role</label>
          <input type="text" class="form-control"  name="role" value="<?php echo $result;?>" readonly>
        </div>
        <div class="form-group col-md-6">
          <label for="inputPassword4">Status</label>
          <select id="inputState" class="form-control" name="status">
            <option <?php echo ($status == 0) ? "selected" : "" ?> value="0">Inactive</option>
            <option <?php echo ($status == 1) ? "selected" : "" ?> value="1">Active</option>
          </select>
        </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-12">
                <label for="inputAddress">Address</label>
                <input type="text" class="form-control" id="inputAddress" name="address" placeholder="1234 Main St" value="<?php echo $address; ?>">
            </div>
        </div>
        <div class="form-group col-md-2">
        <button type="submit" class="btn btn-primary" name="update">Update</button>
    </div>
        </form>
    </div>
</div>
<?php
    if(isset($_POST['update']))
    {
        $sql = query("UPDATE users SET first_name ='{$_POST['first-name']}',last_name ='{$_POST['last-name']}',phone ='{$_POST['phone']}',email ='{$_POST['email']}',address ='{$_POST['address']}',password ='{$_POST['password']}',status ='{$_POST['status']}' WHERE user_id='{$_GET['id']}'");
        confirm($sql);
        set_message("User has Successfully Updated");
        redirect("user_detail_view.php?id=".$_GET['id']);
    }
    
?>