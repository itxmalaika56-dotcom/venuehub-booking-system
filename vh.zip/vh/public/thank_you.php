<?php require_once("../resources/config.php");   ?>
<?php include(TEMPLATE_FRONT.DS."header.php");?>
<h2 class="bg-success"><?php display_message(); ?></h2>
<a href="index.php" class="btn btn-success">Go To Home</a>
<?php include(TEMPLATE_FRONT.DS."footer.php");?>