<?php ob_start();

session_start();
//session_destroy();
//installation Package
//XAMPP + Editor (Sublime Text, Bracket, Visual Studio Code)
//Front end + Back end
//Front end (HTML5,CSS3,Javascript,Bootstrap,jquery)
//Back end (PHP,AJAX)
//Database mysql
//Server Apache

defined("DS") ? null : define("DS",DIRECTORY_SEPARATOR);
defined("TEMPLATE_BACK") ? null : define("TEMPLATE_BACK", __DIR__ . DS . "templates/back");
defined("TEMPLATE_BACK_ADMIN") ? null : define("TEMPLATE_BACK_ADMIN", __DIR__ . DS . "templates/superadminback");
defined("TEMPLATE_FRONT") ? null : define("TEMPLATE_FRONT", __DIR__ . DS . "templates/front");
defined("UPLOAD_DIRECTORY") ? null : define("UPLOAD_DIRECTORY", __DIR__ . DS . "uploads");
defined("UPLOAD_RECEIPT") ? null : define("UPLOAD_RECEIPT", __DIR__ . DS . "receipt");

//Server Name, Database Username, Database Password, Database Name

defined("DB_HOST") ? null : define("DB_HOST", "localhost");
defined("DB_USER") ? null : define("DB_USER", "root");
defined("DB_PASS") ? null : define("DB_PASS", "");
defined("DB_NAME") ? null : define("DB_NAME", "vh_db");

$connection = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);

require_once("functions.php");

?>