<?php
// $_SESSION['user_id'] = "";
// $_SESSION['marriage_hall_status'] = "";
//////// Helper Functions///////
$upload_directory = "uploads";
function last_id(){

	global $connection;
	
	return mysqli_insert_id($connection);
	
	
	}
function set_message($msg)
{
	if(!empty($msg))
	{
		$_SESSION['message']=$msg;
	}
	else
	{
		$msg = "";
	}
}
function display_message()
{
	if(isset($_SESSION['message']))
	{
		echo $_SESSION['message'];
		unset($_SESSION['message']);
	}
}



function redirect($location)
{
	header("Location:$location");
}


function query($sql)
{
	global $connection;
	return mysqli_query($connection,$sql);
}

function confirm($result)
{
	global $connection;
	if(!$result)
	{
		die("QUERY FAILED".mysqli_error($connection));
	}
}


function escape_string($string)
{
	global $connection;
	return mysqli_real_escape_string($connection,$string);
}

function fetch_array($result)
{
	return mysqli_fetch_array($result);
}

///////User Registration/////////
function sign_up()
{
	if(isset($_POST['sign-up']))
	{
		$first_name = escape_string($_POST['first-name']);
		$last_name = escape_string($_POST['last-name']);
		$username = escape_string($_POST['username']);
		$password = escape_string($_POST['password']);
		$email = escape_string($_POST['email']);
		$phone = escape_string($_POST['phone']);
		$address = escape_string($_POST['address']);
		$role = escape_string($_POST['role']);
		$status = escape_string($_POST['status']);
		$query = query("INSERT INTO users(username,password,first_name,last_name,email,phone,address,role,status) VALUES('{$username}','{$password}','{$first_name}','{$last_name}','{$email}','{$phone}','{$address}','{$role}','{$status}')");
		confirm($query);
		if($status==0)
		{
			set_message("Your Application has submitted successfully & Your account is under review. Please Wait for Approval.");
			redirect("sign_up.php");
		}
		else
		{
			set_message("Your Application has been created successfully");
			redirect("login.php");
		}
		
	}
	
}
///////user login//////
function log_in()
{
	if(isset($_POST['login']))
	{
		$user_email = escape_string($_POST['username-email']);
		$password = escape_string($_POST['password']);
		$query = query("SELECT * FROM users WHERE password = '{$password}' AND (email = '{$user_email}' OR username = '{$user_email}')");
		confirm($query);
		if(mysqli_num_rows($query) != 0)
		{
			while($row = fetch_array($query))
			{
				if($row['status'] == 0 && $row['role'] == 1)
				{
					$_SESSION['user-status'] = $row['status'];
					set_message("Your account is under review");
					redirect("login.php");
				}
				elseif($row['status'] == 1 && $row['role'] == 1)
				{
					$_SESSION['username'] = $row['username'];
					$_SESSION['user_id'] = $row['user_id'];
					$_SESSION['role'] = $row['role'];
					$_SESSION['user-status'] = $row['status'];
					redirect("admin");
				}
				elseif($row['status'] == 1 && $row['role'] == 0 && $row['username'] == "superadmin")
				{
					$_SESSION['username'] = $row['username'];
					$_SESSION['user_id'] = $row['user_id'];
					$_SESSION['role'] = $row['role'];
					$_SESSION['user-status'] = $row['status'];
					redirect("superadmin");
				}
				elseif($row['status'] == 1 && $row['role'] == 2)
				{
					$_SESSION['username'] = $row['username'];
					$_SESSION['user_id'] = $row['user_id'];
					redirect('index.php');
				}
				else
				{
					redirect('index.php');
				}
			}
		}
		else
		{
			set_message("Username or Password is invalid");
			redirect("login.php");
		}
	}
	
}
//////////Add Marriage Hall////////////
function add_marriage_hall()
{
	if(isset($_POST['submit']))
	{
		$marriage_hall_name = escape_string($_POST['marriage-hall-name']);
		$phone = escape_string($_POST['phone-number']);
		$email = escape_string($_POST['email']);
		$city = escape_string($_POST['city']);
		$zip = escape_string($_POST['zip-code']);
		$halls = escape_string($_POST['halls']);
		$address = escape_string($_POST['address']);
		$per_head_charges = escape_string($_POST['per-head-charges']);
		$logo = escape_string($_FILES['logo']['name']);
        $image = escape_string($_FILES['image']['name']);
        move_uploaded_file($_FILES['logo']['tmp_name']  , UPLOAD_DIRECTORY . DS . $logo);
        move_uploaded_file($_FILES['image']['tmp_name']  , UPLOAD_DIRECTORY . DS . $image);
        $user_id = $_SESSION['user_id'];
        $query = query("INSERT INTO marriage_hall(marriage_hall_name,halls_in_marriage_hall,marriage_hall_address,marriage_hall_phone,marriage_hall_email,marriage_hall_city,marriage_hall_zip_code,marriage_hall_logo,marriage_hall_image,per_head_charges,user_id) VALUES('{$marriage_hall_name}','{$halls}','{$address}','{$phone}','{$email}','{$city}','{$zip}','{$logo}','{$image}','{$per_head_charges}','{$user_id}')");
                confirm($query);
                set_message("Marriage Hall added Successfully. But in Review");
                redirect("index.php");
	}
}
/////////View Hall in Admin///////////
function view_halls()
{
	$query = query("SELECT * FROM marriage_hall_line WHERE marriage_hall_id='{$_SESSION['marriage_hall_id']}'");
	confirm($query);
	while($row = fetch_array($query))
	{
		if($row['floor']==-1)
		{
			$floor = "Basement";
		}elseif($row['floor']==0)
		{
			$floor = "Ground";
		}
		else
		{
			$floor = $row['floor'];
		}
		$result = <<<DELIMETER
		<tr>
			<td>{$row['marriage_hall_line_name']}</td>
			<td>{$floor}</td>
			<td>{$row['capacity']}</td>
			<td>
				<a class="btn btn-info" href="edit_hall.php?id={$row['marriage_hall_line_id']}"><i class="fa fa-edit"></i></a>
				<a class="btn btn-danger" href="delete_hall.php?id={$row['marriage_hall_line_id']}"><i class="fa fa-remove"></i></a>
			</td>
		</tr>
		DELIMETER;
		echo $result;
	}
}
// ////////////Add Services Line////////////
function show_services_admin()
{
	$query = query("SELECT * FROM services");
	confirm($query);
	while ($row = fetch_array($query)) {
		$result = <<<DELIMETER
		<option value={$row['service_id']}>{$row['service_name']}</option>
		DELIMETER;
		echo $result;
	}
}
function add_services_hall_admin()
{
	if(isset($_POST['submit']))
	{
		$name = escape_string($_POST['service-name']);
		$charges = escape_string($_POST['service-charges']);
		$description = escape_string($_POST['service-desription']);
		$category = escape_string($_POST['service-category']);
		$marriage_hall_id = $_SESSION['marriage_hall_id'];
		$query = query("INSERT INTO service_line(service_id,service_line_name,service_per_unit_charges,service_description,marriage_hall_id) VALUES('{$category}','{$name}','{$charges}','{$description}','{$marriage_hall_id}')");
		confirm($query);
		set_message("Service Has Been Added Successfully");
		redirect("index.php?add_services");
	}
}
// ////////Show Services in Admin/////////
function show_service_line()
{
	$query = query("SELECT * FROM view_service WHERE marriage_hall_id='{$_SESSION['marriage_hall_id']}'");
	confirm($query);
	while ($row = fetch_array($query)) {
		$result = <<<DELIMETER
		<tr>
			<td>{$row['service_line_name']}</td>
			<td>{$row['service_name']}</td>
			<td>{$row['service_per_unit_charges']}</td>
			<td>{$row['service_description']}</td>
			<td>
				<a class="btn btn-info" href="#"><i class="fa fa-edit"></i></a>
				<a class="btn btn-danger" href="#"><i class="fa fa-remove"></i></a>
			</td>

		</tr>
		DELIMETER;
		echo $result;
	}
}
function payment()
{
	if(isset($_POST['submit_payment']))
		{
			date_default_timezone_set("Asia/Karachi");
			$date = date('Y-m-d H:i:s');
			$user = $_SESSION['user_id'];
			$booking = $_GET['id'];
			$method = $_POST['payment_method'];
			$amount = $_POST['amount'];
			$transaction = $_POST['transaction_id'];
			$status = 0;
			$receipt = escape_string($_FILES['receipt']['name']);
        	move_uploaded_file($_FILES['receipt']['tmp_name']  , UPLOAD_RECEIPT . DS . $receipt);
			$query = query("INSERT INTO payment(user_id,booking_id,payment_method,amount,transaction_id,payment_receipt,payment_date,payment_status) VALUES('{$user}','{$booking}','{$method}','{$amount}','{$transaction}','{$receipt}','{$date}','{$status}')");
			confirm($query);
		}
} 
function booking_history() 
{ 
    $query = query("SELECT * FROM view_booking WHERE user_id = '{$_SESSION['user_id']}'"); 
    confirm($query); 

    while($row = fetch_array($query)) 
    { 
        // Status
        if($row['status'] == 0) 
        { 
            $status = "Inactive";

            // Jab admin approve nahi karega
            $action = "<span class='btn btn-secondary'>Waiting for Approval</span>";
        } 
        else 
        { 
            $status = "Active";

            // Jab admin approve kar dega
            $action = "<a href='payment.php?id=" . $row['booking_id'] . "' class='btn btn-info'>Pay Now</a>";
        } 


        // Shift
        if($row['booking_shift'] == 0) 
        { 
            $shift = "Noon"; 
        } 
        else 
        { 
            $shift = "Evening"; 
        } 


        // Booking row
        $bookings = "
        <tr> 
            <td>" . $row['booking_id'] . "</td> 
            <td>" . $row['marriage_hall_line_name'] . "</td> 
            <td>" . $row['first_name'] . " " . $row['last_name'] . "</td> 
            <td>" . $row['phone'] . "</td> 
            <td>" . $row['booking_date'] . "</td> 
            <td>" . $shift . "</td> 
            <td>" . $status . "</td> 
            <td>" . $action . "</td>
        </tr>
        ";

        echo $bookings; 
    } 
}
///////////SUPER ADMIN FUNCTIONS//////////////
function view_marriage_hall()
{
	$status = "";
	$query = query("SELECT * FROM marriage_hall");
	confirm($query);
	while($row = fetch_array($query))
	{
		if($row['marriage_hall_status'] == 1)
		{
			$status = "Active";
		}
		else
		{
			$status = "Inactive";
		}
$marriage_halls = <<<DELIMETER
<tr>
        <td>{$row['marriage_hall_name']}</td>
        <td>{$row['marriage_hall_email']}</td>
        <td>{$row['marriage_hall_phone']}</td>
        <td>{$row['marriage_hall_address']}</td>
        <td>{$status}</td>
        <td><a href="marriage_hall_detail.php?id={$row['marriage_hall_id']}" class="btn btn-info">Detail</a></td>
</tr>
DELIMETER;
            echo $marriage_halls;
	}
}
// function detail_view_marriage_hall()
// {
// 	if(isset($_GET['id']))
// 	{
// 		$query = query("SELECT * FROM marriage_hall WHERE marriage_hall_id='{$_GET['id']}'");
// 		confirm($query);
// 		while($row = fetch_array($query))
// 		{
// 			echo $row['marriage_hall_name'];
// 		}
// 	}
// }
function show_marriage_hall_superadmin_page()
{
	$query = query("SELECT * FROM marriage_hall WHERE marriage_hall_status='1'");
	confirm($query);
	while ($row = fetch_array($query)) {
		$result = <<<DELIMETER
		<option value="{$row['marriage_hall_id']}">{$row['marriage_hall_name']}</option>
		DELIMETER;
		echo $result;
	}
}
function view_hall_superadmin()
{
	if(isset($_POST['submit']))
	{
		$marriage_hall_id = escape_string($_POST['marriage-hall-name']);
		$query = query("SELECT * FROM marriage_hall_line WHERE marriage_hall_id='{$marriage_hall_id}'");
		confirm($query);
		while ($row = fetch_array($query)) {
			if($row['floor'] == -1)
			{
				$floor = "Basement";
			}
			elseif($row['floor'] == 0)
			{
				$floor = "Ground";
			}
			else
			{
				$floor = $row['floor'];
			}
			$result = <<<DELIMETER
			<tr>
				<td>{$row['marriage_hall_line_name']}</td>
				<td>{$floor}</td>
				<td>{$row['capacity']}</td>
			</tr>
			DELIMETER;
			echo $result;
		}
	}
}
function view_users()
{
	$status = "";
	$role = "";
	$query = query("SELECT * FROM users WHERE role='1' OR role='2'");
	confirm($query);
	while($row = fetch_array($query))
	{
		if($row['status'] == 1)
		{
			$status = "Active";
		}
		else
		{
			$status = "Inactive";
		}
		if($row['role'] == 1)
		{
			$role = "Hall Admin";
		}
		else
		{
			$role = "Guest";
		}
$users = <<<DELIMETER
<tr>
        <td>{$row['first_name']}</td>
        <td>{$row['last_name']}</td>
        <td>{$row['username']}</td>
        <td>{$row['email']}</td>
        <td>{$row['phone']}</td>
        <td>{$row['address']}</td>
        <td>{$role}</td>
        <td>{$status}</td>
        <td><a href="user_detail_view.php?id={$row['user_id']}" class="btn btn-info">Detail</a></td>
</tr>
DELIMETER;
            echo $users;
	}
}
////////////Add Services////////////
function add_services()
{
	if(isset($_POST['submit']))
	{
		$name = escape_string($_POST['service-name']);
		$query = query("INSERT INTO services(service_name) VALUES('{$name}')");
		confirm($query);
		set_message("Service Has Been Added Successfully");
		redirect("index.php?add_services");
	}
}
////////Show Services in Admin/////////
function show_services()
{
	$query = query("SELECT * FROM services");
	confirm($query);
	while ($row = fetch_array($query)) {
		$result = <<<DELIMETER
		<tr>
			<td>{$row['service_name']}</td>
		</tr>
		DELIMETER;
		echo $result;
	}
}
//////////////Client Side////////////////
function show_marriage_hall_client_side()
{
	$query = query("SELECT * FROM marriage_hall WHERE marriage_hall_status=1");
	confirm($query);
	while ($row = fetch_array($query)) {
$result = <<<DELIMETER
<div class="col-lg-4">
    <div class="card">
      <img
        src="../resources/uploads/{$row['marriage_hall_image']}"
        class="card-img-top"
        alt="Waterfall" height="250" width="250"
      />
      <div class="card-body">
        <h5 class="card-title">{$row['marriage_hall_name']}</h5>
        <a href="marriage_hall_detail.php?id={$row['marriage_hall_id']}" class="btn btn-primary">More Detail</a>
      </div>
    </div>
  </div>
DELIMETER;
	echo $result;
	}
}
function hall_detail()
{
	$query = query("SELECT * FROM marriage_hall_line WHERE marriage_hall_id = '{$_GET['id']}'");
	confirm($query);
	while ($row = fetch_array($query)) {
		if($row['floor'] == -1)
		{
			$floor = "Basement";
		}
		elseif($row['floor'] == 0)
		{
			$floor = "Ground";
		}
		else
		{
			$floor = $row['floor'];
		}
		$result = <<<DELIMETER
		<tr>
		<td>{$row['marriage_hall_line_name']}</td>
		<td>{$floor}</td>
		<td>{$row['capacity']}</td>
		<td><a href="add_booking.php?hall_id={$row['marriage_hall_line_id']}&m_id={$_GET['id']}" class="btn btn-primary btn-rounded">Book Now</a></td>
		</tr>
		DELIMETER;
		echo $result;
	}
}
//////show services on Booking Page////////
function deal_service()
{
 	if(isset($_GET['m_id']))
	{
		$query = query("SELECT * FROM view_service WHERE marriage_hall_id='{$_GET['m_id']}' AND service_name = 'Deals'");
		confirm($query);
		while($row = fetch_array($query))
		{	
$result = <<<DELIMETER
<div class="col-lg-4 col-md-8">
                      <div class="price-item">
                          <h4>{$row['service_line_name']}</h4>
                          <div class="pi-price">
                              <h2>Rs: {$row['service_per_unit_charges']}</h2>
                          </div>
                          <ul>
                          	<li>{$row['service_description']}</li>
                          </ul>
                          <div class="price-btn">
                            <input type="radio" name="deal" value="{$row['service_line_id']}" required> Get Deal
                          </div>
                      </div>
                  </div>
DELIMETER;
			echo $result;
		}
	}
}
//////////checkout//////////
// function checkout()
// {
// 	 if(isset($_POST['submit']))
//   	{
// 	    $marriage_hall_id = $_POST['marriage-hall'];
// 	    $hall_id = $_POST['hall'];
// 	    $date = $_POST['event-date'];
// 	    $shift = $_POST['event-shift'];
// 	    $guests = $_POST['event-guest'];
// 	    $deal = $_POST['deal'];
// 	    if($deal!=0)
// 	    {
	    	
// 	    }
// 	}
// }
//////////////Booking Confirmation///////////
function booking_confirmation()
{
	$query = query("SELECT * FROM view_booking WHERE marriage_hall_id = '{$_SESSION['marriage_hall_id']}'");
	confirm($query);
	while($row = fetch_array($query))
	{
		if($row['status'] == 0)
		{
			$status = "Inactive";
		}
		else
		{
			$status = "Active";
		}
		if($row['booking_shift'] == 0)
		{
			$shift = "Noon";
		}
		else
		{
			$shift = "Evening";
		}
		$bookings = <<<DELIMETER
		<tr>
		        <td>{$row['booking_id']}</td>
		        <td>{$row['marriage_hall_line_name']}</td>
		        <td>{$row['first_name']} {$row['last_name']}</td>
		        <td>{$row['phone']}</td>
		        <td>{$row['booking_date']}</td>
		        <td>{$shift}</td>
		        <td>{$status}</td>
		        <td>
		        	<a href="edit_booking.php?id={$row['booking_id']}" class="btn btn-info"><i class="fa fa-edit"></i></a>
		        	<a href="delete_booking.php?id={$row['booking_id']}" class="btn btn-danger"><i class="fa fa-remove"></i></a>
		        </td>
		</tr>
		DELIMETER;
            	echo $bookings;
	}
}

///////////Dashboard Features//////////
function active_users()
{
	$query = query("SELECT * FROM users WHERE status=1");
	confirm($query);
	$active_users = mysqli_num_rows($query);
	echo $active_users;
}
function inactive_users()
{
	$query = query("SELECT * FROM users WHERE status=0");
	confirm($query);
	$inactive_users = mysqli_num_rows($query);
	echo $inactive_users;
}
function confirm_halls()
{
	$query = query("SELECT * FROM marriage_hall WHERE marriage_hall_status=1");
	confirm($query);
	$halls = mysqli_num_rows($query);
	echo $halls;
}
function pending_halls()
{
	$query = query("SELECT * FROM marriage_hall WHERE marriage_hall_status=0");
	confirm($query);
	$pending_halls = mysqli_num_rows($query);
	echo $pending_halls;
}
?>