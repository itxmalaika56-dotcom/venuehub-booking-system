<script type="text/javascript" src="../admin/js/jquery.js"></script>
<?php include("save_hall_line.php");?>
<h3 class="bg-success text-center"><?php display_message(); ?></h3>
<h3>Add Hall Detail</h3>
<form class="form-horizontal" method="POST" action="" id="hall_form">
    <input type="hidden" name="marriage_hall_line" id="marriage_hall_line">
    <table class="table table-responsive table-striped table-bordered">
        <thead>
            <tr>
                <th>Hall Name</th>
                <th>Floor</th>
                <th>Capacity</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <tr class="parent_tr">
                <td><input type="text" class="form-control" id="hall-name" name="hall-name" required/></td>
                <td><input type="number" class="form-control" id="floor" name="floor" placeholder="-1 for Basement, 0 for ground..." required/></td>
                <td><input type="number" class="form-control" id="capacity" name="capacity" required/></td>
                <td>
                    <a href="javascript:void(0)" class="btn btn-success addRow">+</a>
                    <a href="javascript:void(0)" class="btn btn-danger deleteRow">-</a>
                </td>
            </tr>
        </tbody>
        <tfoot>
            <tr>
                <th>Hall Name</th>
                <th>Floor</th>
                <th>Capacity</th>
                <th></th>
            </tr>
        </tfoot>
    </table>
    <input value="Submit" class="btn btn-success pull-right" type="submit" name="add_hall_line" id="add_hall_line" onclick="return save_marriage_hall_line()"/>
</form>
<script type="text/javascript">
    $('tbody').on('click','.addRow',function(){
        var tr = "<tr class='parent_tr'>"+
                    "<td><input type='text' class='form-control' id='hall-name' name='hall-name' required/></td>"+
                    "<td><input type='number' class='form-control' id='floor' name='floor' placeholder='-1 for Basement, 0 for ground...' required /></td>"+
                    "<td><input type='number' class='form-control' id='capacity' name='capacity' required/></td>"+
                    "<td>"+
                        "<a href='javascript:void(0)' class='btn btn-success addRow'>+</a> "+
                        "<a href='javascript:void(0)' class='btn btn-danger deleteRow'>-</a>"+
                    "</td>"+
                "</tr>"
            $('tbody').append(tr);
    });
    $('tbody').on('click', '.deleteRow', function(){
        $(this).parent().parent().remove();
    });


function save_marriage_hall_line()
{
    var arry = [];
    $('.parent_tr').each(function(){
        var name = $(this).find("#hall-name").val();
        var floor = $(this).find("#floor").val();
        var capacity = $(this).find("#capacity").val();
        var marriage_hall_line = new Object();
        marriage_hall_line.hall_name = name;
        marriage_hall_line.hall_floor = floor;
        marriage_hall_line.hall_capacity = capacity;
        arry.push(marriage_hall_line);
    })
    var str_json=JSON.stringify(arry);
        $("#marriage_hall_line").val(str_json);
        return true;
}
    
</script>