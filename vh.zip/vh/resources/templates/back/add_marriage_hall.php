<?php add_marriage_hall(); ?>
<h3>Add Marriage Hall Detail</h3>
  <form class="px-md-2" action="" method="post" enctype="multipart/form-data">
    <div class="form-outline mb-4">
      <input type="text" id="marriage-hall-name" class="form-control"  name="marriage-hall-name" required pattern="[A-Za-z ]+" required/>
      <label class="form-label" for="form3Example1q">Marriage Hall Name</label>
    </div>
    <div class="row">
      <div class="col-md-3">
        <div class="form-outline mb-4">
          <input type="text" id="phone-number" class="form-control"  name="phone-number" required pattern="[0-9]+" required/>
          <label class="form-label" for="form3Example1q">Phone Number</label>
        </div>
      </div>
      <div class="col-md-3">
        <div class="form-outline mb-4">
          <input type="email" id="email" class="form-control"  name="email" required pattern="[a-zA-Z0-9._%+-]+@gmail\.com"required/>
          <label class="form-label" for="form3Example1q">Email Address</label>
        </div>
      </div>
      <div class="col-md-3">
        <div class="form-outline mb-4">
          <input type="text" id="city" class="form-control"  name="city" required pattern="[A-Za-z ]+"required/>
          <label class="form-label" for="form3Example1q">city</label>
        </div>
      </div>
      <div class="col-md-3">
        <div class="form-outline mb-4">
          <input type="text" id="zip-code" class="form-control"  name="zip-code" required/>
          <label class="form-label" for="form3Example1q">Zip Code</label>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-4">
          <div class="form-outline mb-4">
              <input type="file" id="logo" class="form-control"  name="logo" required/>
              <label class="form-label" for="form3Example1q">Marriage Hall Logo</label>
          </div>
      </div>
      <div class="col-md-4">
        <div class="form-outline mb-4">
              <input type="file" id="image" class="form-control"  name="image" required/>
              <label class="form-label" for="form3Example1q">Marriage Hall Image</label>
            </div>
      </div>
      <div class="col-md-4">
          <div class="form-outline mb-4">
      <input type="text" id="halls" class="form-control"  name="halls"  required pattern="[0-9]+" required/>
      <label class="form-label" for="form3Example1q">No. of Halls </label>
    </div>
      </div>
    </div>
     <div class="form-outline mb-4">
        <textarea type="text" id="address" class="form-control"  name="address" required></textarea>
        <label class="form-label" for="form3Example1q">Address</label>
      </div>
      <input type="text" name="per-head-charges" value="0" hidden>
    <input type="submit" class="btn btn-success btn-lg mb-1" name="submit" id="submit" value="Submit" />
  </form>