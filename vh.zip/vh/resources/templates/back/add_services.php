<?php
	$query = query("SELECT * FROM marriage_hall WHERE user_id='{$_SESSION['user_id']}'");
	confirm($query);
	while($row = fetch_array($query))
	{
		$_SESSION['marriage_hall_id'] = $row['marriage_hall_id'];
	}
?>
<h3 class="bg-success text-center"><?php display_message(); ?></h3>
<h3>Add Services</h3>
<div class="row">
	<div class="col-md-4">
		<form method="post">
			<label>Select Service Category</label>
			<select class="form-control" name="service-category" required>
				<option>Select Any Category</option>
				<?php show_services_admin(); ?>
			</select>
			<label>Enter Service Name</label>
			<input type="text" class="form-control" name="service-name">
			<label>Enter Service Charges</label>
			<input type="number" class="form-control" name="service-charges">
			<label>Enter Service Desription</label>
			<textarea type="text" class="form-control" name="service-desription"></textarea>
			<br>
			<input type="submit" name="submit" class="btn btn-success">
			<?php add_services_hall_admin(); ?>
		</form>
	</div>
	<div class="col-md-8">
		<table class="table table-striped table-bordered">
			<thead>
				<th>Service Name</th>
				<th>Category</th>
				<th>Charges</th>
				<th>Description</th>
				<th></th>
			</thead>
			<tbody>
				<?php show_service_line(); ?>
			</tbody>
			<tfoot>
				<th>Service Name</th>
				<th>Category</th>
				<th>Charges</th>
				<th>Description</th>
				<th></th>
			</tfoot>
		</table>
	</div>
</div>