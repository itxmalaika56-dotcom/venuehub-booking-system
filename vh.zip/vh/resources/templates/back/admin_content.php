<?php
/*
 * Venue Hub - Admin Dashboard
 *
 * Uses the existing project database/tables:
 *   marriage_hall, booking, payment, view_booking
 *
 * Cards:
 *   1. Total Bookings
 *   2. Approved Bookings
 *   3. Pending Bookings
 *
 * Table:
 *   Transaction History (real payment records)
 */

// Find the marriage hall belonging to the logged-in admin.
$hall_id = 0;

$hall_query = query("SELECT marriage_hall_id FROM marriage_hall WHERE user_id = '{$_SESSION['user_id']}' LIMIT 1");
confirm($hall_query);

if ($hall_row = fetch_array($hall_query)) {
    $hall_id = (int)$hall_row['marriage_hall_id'];
    $_SESSION['marriage_hall_id'] = $hall_id;
}

// ------------------------------------------------------------
// Booking counts
// ------------------------------------------------------------
$total_bookings = 0;
$approved_bookings = 0;
$pending_bookings = 0;

if ($hall_id > 0) {

    $total_query = query("SELECT COUNT(*) AS total FROM booking WHERE marriage_hall_id = '{$hall_id}'");
    confirm($total_query);
    if ($row = fetch_array($total_query)) {
        $total_bookings = (int)$row['total'];
    }

    $approved_query = query("SELECT COUNT(*) AS total FROM booking WHERE marriage_hall_id = '{$hall_id}' AND status = 1");
    confirm($approved_query);
    if ($row = fetch_array($approved_query)) {
        $approved_bookings = (int)$row['total'];
    }

    $pending_query = query("SELECT COUNT(*) AS total FROM booking WHERE marriage_hall_id = '{$hall_id}' AND status = 0");
    confirm($pending_query);
    if ($row = fetch_array($pending_query)) {
        $pending_bookings = (int)$row['total'];
    }
}
?>

<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
            Dashboard <small>Marriage Hall Booking Overview</small>
        </h1>
        <ol class="breadcrumb">
            <li class="active">
                <i class="fa fa-dashboard"></i> Dashboard
            </li>
        </ol>
    </div>
</div>

<!-- ==========================================================
     BOOKING STATISTICS
     ========================================================== -->
<div class="row">

    <!-- TOTAL BOOKINGS -->
    <div class="col-lg-4 col-md-4">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-calendar fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge"><?php echo $total_bookings; ?></div>
                        <div>Total Bookings</div>
                    </div>
                </div>
            </div>
            <a href="index.php?view_booking">
                <div class="panel-footer">
                    <span class="pull-left">View Bookings</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>

    <!-- APPROVED BOOKINGS -->
    <div class="col-lg-4 col-md-4">
        <div class="panel panel-green">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-check-circle fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge"><?php echo $approved_bookings; ?></div>
                        <div>Approved Bookings</div>
                    </div>
                </div>
            </div>
            <a href="index.php?view_booking">
                <div class="panel-footer">
                    <span class="pull-left">View Approved</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>

    <!-- PENDING BOOKINGS -->
    <div class="col-lg-4 col-md-4">
        <div class="panel panel-yellow">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-clock-o fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge"><?php echo $pending_bookings; ?></div>
                        <div>Pending Bookings</div>
                    </div>
                </div>
            </div>
            <a href="index.php?view_booking">
                <div class="panel-footer">
                    <span class="pull-left">View Pending</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>

</div>

<!-- ==========================================================
     TRANSACTION HISTORY
     ========================================================== -->
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">
                    <i class="fa fa-money fa-fw"></i> Transaction History
                </h3>
            </div>

            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover table-striped">
                        <thead>
                            <tr>
                                <th>Booking #</th>
                                <th>Customer</th>
                                <th>Payment Method</th>
                                <th>Transaction ID</th>
                                <th>Amount (PKR)</th>
                                <th>Payment Date</th>
                                <th>Payment Status</th>
                            </tr>
                        </thead>
                        <tbody>

                        <?php
                        if ($hall_id > 0) {

                            /*
                             * payment contains the real transaction data.
                             * view_booking gives us the customer and hall information.
                             */
                            $transaction_query = query(
                                "SELECT
                                    p.booking_id,
                                    p.payment_method,
                                    p.amount,
                                    p.transaction_id,
                                    p.payment_date,
                                    p.payment_status,
                                    v.first_name,
                                    v.last_name
                                 FROM payment p
                                 INNER JOIN view_booking v ON v.booking_id = p.booking_id
                                 WHERE v.marriage_hall_id = '{$hall_id}'
                                 ORDER BY p.payment_date DESC
                                 LIMIT 10"
                            );
                            confirm($transaction_query);

                            if (mysqli_num_rows($transaction_query) > 0) {

                                while ($transaction = fetch_array($transaction_query)) {

                                    $customer_name = trim(
                                        $transaction['first_name'] . ' ' . $transaction['last_name']
                                    );

                                    if ($customer_name == '') {
                                        $customer_name = 'Customer';
                                    }

                                    // Existing project uses 0/1 for payment status.
                                    if ((int)$transaction['payment_status'] == 1) {
                                        $payment_status = '<span class="label label-success">Paid</span>';
                                    } else {
                                        $payment_status = '<span class="label label-warning">Pending</span>';
                                    }
                                    ?>

                                    <tr>
                                        <td><?php echo htmlspecialchars($transaction['booking_id']); ?></td>
                                        <td><?php echo htmlspecialchars($customer_name); ?></td>
                                        <td><?php echo htmlspecialchars($transaction['payment_method']); ?></td>
                                        <td><?php echo htmlspecialchars($transaction['transaction_id']); ?></td>
                                        <td>Rs. <?php echo number_format((float)$transaction['amount'], 2); ?></td>
                                        <td><?php echo htmlspecialchars($transaction['payment_date']); ?></td>
                                        <td><?php echo $payment_status; ?></td>
                                    </tr>

                                    <?php
                                }

                            } else {
                                ?>
                                <tr>
                                    <td colspan="7" class="text-center">
                                        No transaction history found.
                                    </td>
                                </tr>
                                <?php
                            }

                        } else {
                            ?>
                            <tr>
                                <td colspan="7" class="text-center">
                                    No marriage hall is linked with this admin account.
                                </td>
                            </tr>
                            <?php
                        }
                        ?>

                        </tbody>
                    </table>
                </div>

                <div class="text-right">
                    <a href="index.php?view_booking">
                        View All Bookings <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
