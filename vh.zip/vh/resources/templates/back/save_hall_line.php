<?php
	if(isset($_POST['add_hall_line']))
	{
		$marriage_hall_id = "";
		$user_id = $_SESSION['user_id'];
		$sql = query("SELECT * FROM marriage_hall WHERE user_id='{$user_id}'");
		confirm($sql);
		while($result = fetch_array($sql))
		{
			$marriage_hall_id = $result['marriage_hall_id'];
		}
		// $sql = query("INSERT INTO bulk_order(bulk_order_date) VALUES('{$order_date}')");
		// confirm($sql);
		// $last_id = last_id();
		$str_json = $_POST['marriage_hall_line'];
		$hall_lines_decode = json_decode($str_json,true);

		// redirect('save_order.php');
  foreach ($hall_lines_decode as $row) {
    $query = query("INSERT INTO marriage_hall_line(marriage_hall_id,capacity,floor,marriage_hall_line_name) VALUES('$marriage_hall_id','".$row["hall_capacity"]."','".$row["hall_floor"]."','".$row["hall_name"]."')");
        confirm($query);
        set_message("Your Hall Detail Successfully Added");
 }
	}
?>