<?php
$_SESSION['marriage_hall_status'] = "";
$_SESSION['numbers'] = "";
$query = query("SELECT * FROM marriage_hall WHERE user_id = '{$_SESSION['user_id']}'");
    confirm($query);
    while($row = fetch_array($query))
    {
        if(mysqli_num_rows($query)>0)
        {
            $_SESSION['marriage_hall_status'] = $row['marriage_hall_status'];
            $_SESSION['numbers'] = 1;
        }
    }
    ?>
<div class="collapse navbar-collapse navbar-ex1-collapse">
    <ul class="nav navbar-nav side-nav" style="min-height: -webkit-fill-available; top: 50px;">
        <li class="active">
            <a href="index.php"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
        </li>
        <?php if($_SESSION['numbers'] !=1){?>
        <li>
            <a href="index.php?add_marriage_hall"><i class="fa fa-fw fa-bar-chart-o"></i> Add Marriage Hall</a>
        </li>
    <?php }else{?>
        <li>
            <a href="#" onclick="onalert();"><i class="fa fa-fw fa-bar-chart-o"></i> Add Marriage Hall</a>
        </li>
    <?php } ?>
        <?php if($_SESSION['marriage_hall_status'] == 1){?>
        <li>
            <a href="index.php?add_hall_detail"><i class="fa fa-fw fa-table"></i> Add Hall Detail</a>
        </li>
        <li>
            <a href="index.php?view_hall_detail"><i class="fa fa-fw fa-table"></i> View Hall Detail</a>
        </li>
        <li>
            <a href="index.php?view_booking"><i class="fa fa-fw fa-desktop"></i> view Bookings</a>
        </li>
        <li>
            <a href="index.php?add_services"><i class="fa fa-fw fa-desktop"></i> Add Services</a>
        </li>
        <!-- <li>
            <a href="users.html"><i class="fa fa-fw fa-wrench"></i>Users</a>
        </li> -->
    <?php } ?>
        <!-- <li>
            <a href="../logout.php"><i class="fa fa-fw fa-wrench"></i>logout</a>
        </li> -->
    </ul>
</div>
<script type="text/javascript">
   function onalert()
   {
    alert("You can't add more than one Marriage Hall");
   }
</script>
<!-- <style type="text/css">
    a.noclick       {
  pointer-events: none;
}
</style> -->