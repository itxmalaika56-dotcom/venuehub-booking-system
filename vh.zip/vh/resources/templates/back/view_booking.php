<?php
	$query = query("SELECT * FROM marriage_hall WHERE user_id='{$_SESSION['user_id']}'");
	confirm($query);
	while($row = fetch_array($query))
	{
		$_SESSION['marriage_hall_id'] = $row['marriage_hall_id'];
	}
?>
<link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap4.min.css">
    <link href="css/sb-admin.css" rel="stylesheet">
    <h3 class="bg-success text-center"><?php display_message(); ?></h3>
    <h3 class="text-center">Bookings</h3>

<table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
        <tr>
            <th>Booking #</th>
            <th>Hall Name</th>
            <th>Booker</th>
            <th>Phone #</th>
            <th>Date</th>
            <th>Shift</th>
            <th>Status</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php booking_confirmation(); ?>
    </tbody>
    
</table>
<script src="js/jquery.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript">
        new DataTable('#example');
    </script>
