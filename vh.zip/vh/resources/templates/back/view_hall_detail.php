<?php
	$query = query("SELECT * FROM marriage_hall WHERE user_id='{$_SESSION['user_id']}'");
	confirm($query);
	while($row = fetch_array($query))
	{
		$_SESSION['marriage_hall_id'] = $row['marriage_hall_id'];
	}
?>
<h3 class="bg-success text-center"><?php display_message(); ?></h3>
<a href="index.php?add_hall_detail" class="btn btn-success" style="float: right;"><i class="fa fa-plus"></i>Add More Hall</a>
<br>
<table class="table table-striped table-bordered">
	<thead>
		<th>Hall Name</th>
		<th>Floor</th>
		<th>Capacity</th>
		<th></th>
	</thead>
	<tbody>
		<?php view_halls(); ?>
	
</table>