<section class="hero-section set-bg" data-setbg="img/public_banner.png" style="height: 525px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <div class="hero-text">
                        <!-- <span>All Event Places on One Platform</span> -->
                        <h2>Organize Your Event<br /> On one click</h2>
                        <a href="login.php" class="primary-btn">Book Event</a>
                    </div>
                </div>
                <!-- <div class="col-lg-5">
                    <img src="img/hero-right.png" alt="">
                </div> -->
            </div>
        </div>
    </section>