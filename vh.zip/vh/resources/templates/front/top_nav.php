    <header class="header-section">
        <div class="container">
            <div class="logo">
                <a href="./index.php">
                    <img src="img/logo.jpeg" alt="" style="height:75px;">
                </a>
            </div>
            <div class="nav-menu">
                <nav class="mainmenu mobile-menu">
                    <ul>
                        <li ><a href="index.php">Home</a></li>
                        <li><a href="index.php#about-us">About</a></li>
                        <!-- <li><a href="./speaker.html">Speakers</a>
                            <ul class="dropdown">
                                <li><a href="#">Jayden</a></li>
                                <li><a href="#">Sara</a></li>
                                <li><a href="#">Emma</a></li>
                                <li><a href="#">Harriet</a></li>
                            </ul>
                        </li>
                        <li><a href="./schedule.html">Schedule</a></li> -->
                        <li><a href="index.php#marriage-hall">Marriage Halls</a></li>
                        <li><a href="mailto:oeh@gmail.com">Contacts</a></li>
                        <?php if(!isset($_SESSION['username']) || empty($_SESSION['username']))
                        { ?>
                            <li><a href="./login.php">Login</a></li>
                            <li><a href="./sign_up.php">Register</a></li>
                        <?php }else{ ?>
                            <li><a href="./booking_history.php">History</a></li>
                            <li><a href="./client_logout.php">Logout</a></li>
                      <?php  } ?>
                        
                    </ul>
                </nav>
                <a href="index.php#marriage-hall" class="primary-btn top-btn"><i class="fa fa-ticket"></i> Book Now</a>
            </div>
            <div id="mobile-menu-wrap"></div>
        </div>
    </header>
    <style type="text/css">
        .mainmenu ul > li > a{
            text-decoration: none;
        }
    </style>