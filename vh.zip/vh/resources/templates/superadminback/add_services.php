<h3 class="bg-success text-center"><?php display_message(); ?></h3>
<h3>Add Services</h3>
<div class="row">
	<div class="col-md-4">
		<form method="post">
			<?Php add_services(); ?>
			<input type="text" class="form-control" name="service-name">
			<br>
			<input type="submit" name="submit" class="btn btn-success">
		</form>
	</div>
	<div class="col-md-8">
		<table class="table table-striped table-bordered">
			<thead>
				<th>Service Name</th>
			</thead>
			<tbody>
				<?php show_services(); ?>
			</tbody>
			<tfoot>
				<th>Service Name</th>
			</tfoot>
		</table>
	</div>
</div>