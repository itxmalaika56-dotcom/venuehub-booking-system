<div class="collapse navbar-collapse navbar-ex1-collapse">
    <ul class="nav navbar-nav side-nav" style="min-height: -webkit-fill-available; top: 50px;">
        <li class="active">
            <a href="index.php"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
        </li>
        <li>
            <a href="index.php?view_marriage_halls"><i class="fa fa-solid fa-building"></i> View Marriage Hall</a>
        </li>
        <li>
            <a href="index.php?view_hall_detail"><i class="fa fa-solid fa-building"></i> View Hall Detail</a>
        </li>
        <li>
            <a href="index.php?add_services"><i class="fa fa-fw fa-desktop"></i> Add Services</a>
        </li>
        
        <!-- <li>
            <a href="categories.html"><i class="fa fa-fw fa-desktop"></i> Categories</a>
        </li> -->
        <li>
            <a href="index.php?view_users"><i class="fa fa-solid fa-users"></i> Users</a>
        </li>
    </ul>
</div>