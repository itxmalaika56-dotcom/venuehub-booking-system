<h3 class="">View Marraige Hall Detail</h3>
<div class="row">
	<div class="col-md-4">
		<h3>Select Any Marriage Hall</h3>
		<form method="post">
			<select class="form-control" name="marriage-hall-name">
				<option>Select any Marriage Hall</option>
				<?php show_marriage_hall_superadmin_page(); ?>
			</select><br>
			<input type="submit" class="btn btn-success" name="submit" value="Submit">
		</form>
	</div>
	<div class="col-md-8">
		<table id="example" class="table table-striped table-bordered">
		    <thead>
		        <tr>
		            <th>Hall Name</th>
		            <th>Floor</th>
		            <th>Capacity</th>
		        </tr>
		    </thead>
		    <tbody>
		        <?php view_hall_superadmin();?>
		    </tbody>
		    
		</table>
	</div>
</div>

