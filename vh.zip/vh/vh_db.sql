-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 28, 2026 at 06:44 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vh_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `booking_id` int(11) NOT NULL,
  `marriage_hall_id` int(11) NOT NULL,
  `marriage_hall_line_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `booking_date` date NOT NULL,
  `guests` int(11) NOT NULL,
  `booking_shift` int(11) NOT NULL,
  `booking_bill` int(11) NOT NULL,
  `booking_discount` int(11) NOT NULL,
  `booking_reserve_payment` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`booking_id`, `marriage_hall_id`, `marriage_hall_line_id`, `user_id`, `booking_date`, `guests`, `booking_shift`, `booking_bill`, `booking_discount`, `booking_reserve_payment`, `status`) VALUES
(7, 3, 4, 17, '2026-09-16', 500, 0, 2500000, 0, 250000, 1),
(8, 3, 5, 17, '2026-09-22', 1000, 0, 5000000, 0, 0, 1),
(9, 3, 4, 17, '2026-09-28', 1500, 1, 7500000, 0, 0, 1),
(10, 4, 7, 17, '2026-09-24', 500, 0, 2500000, 0, 0, 0),
(11, 4, 7, 17, '2026-09-22', 300, 0, 1500000, 0, 0, 0),
(12, 4, 7, 17, '2026-09-23', 300, 0, 1500000, 0, 0, 0),
(13, 4, 7, 17, '2026-09-24', 300, 0, 1500000, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `booking_line`
--

CREATE TABLE `booking_line` (
  `booking_line_id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `service_line_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking_line`
--

INSERT INTO `booking_line` (`booking_line_id`, `booking_id`, `service_id`, `service_line_id`) VALUES
(7, 7, 5, 6),
(8, 8, 5, 6),
(9, 9, 5, 6),
(10, 10, 5, 7),
(11, 11, 5, 7),
(12, 12, 5, 7),
(13, 13, 5, 7);

-- --------------------------------------------------------

--
-- Table structure for table `marriage_hall`
--

CREATE TABLE `marriage_hall` (
  `marriage_hall_id` int(11) NOT NULL,
  `marriage_hall_name` varchar(255) NOT NULL,
  `halls_in_marriage_hall` int(11) NOT NULL,
  `marriage_hall_address` text NOT NULL,
  `marriage_hall_phone` varchar(255) NOT NULL,
  `marriage_hall_email` varchar(255) NOT NULL,
  `marriage_hall_city` text NOT NULL,
  `marriage_hall_zip_code` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `marriage_hall_logo` varchar(255) NOT NULL,
  `marriage_hall_image` varchar(255) NOT NULL,
  `per_head_charges` int(11) NOT NULL,
  `marriage_hall_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `marriage_hall`
--

INSERT INTO `marriage_hall` (`marriage_hall_id`, `marriage_hall_name`, `halls_in_marriage_hall`, `marriage_hall_address`, `marriage_hall_phone`, `marriage_hall_email`, `marriage_hall_city`, `marriage_hall_zip_code`, `user_id`, `marriage_hall_logo`, `marriage_hall_image`, `per_head_charges`, `marriage_hall_status`) VALUES
(4, 'Zam Zam Marriage Hall ', 1, 'Kharian village naseera', '03167187688', 'itxmalaika56@gmail.com', 'Lalamusa', '50090', 10, 'zam zam marriage hall.jfif', 'zam zam marriage hall.jfif', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `marriage_hall_line`
--

CREATE TABLE `marriage_hall_line` (
  `marriage_hall_line_id` int(11) NOT NULL,
  `marriage_hall_id` int(11) NOT NULL,
  `capacity` int(11) NOT NULL,
  `floor` int(11) NOT NULL,
  `marriage_hall_line_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `marriage_hall_line`
--

INSERT INTO `marriage_hall_line` (`marriage_hall_line_id`, `marriage_hall_id`, `capacity`, `floor`, `marriage_hall_line_name`) VALUES
(7, 4, 1000, -1, 'Hall 1'),
(8, 4, 1500, 0, 'Hall 2 '),
(9, 4, 2000, 1, 'Hall 3');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `payment_method` varchar(255) NOT NULL,
  `amount` float NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `payment_reciept` varchar(255) NOT NULL,
  `payment_date` datetime NOT NULL,
  `payment_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `service_id` int(11) NOT NULL,
  `service_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`service_id`, `service_name`) VALUES
(5, 'Deals');

-- --------------------------------------------------------

--
-- Table structure for table `service_line`
--

CREATE TABLE `service_line` (
  `service_line_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `service_line_name` varchar(255) NOT NULL,
  `service_per_unit_charges` float NOT NULL,
  `service_description` text NOT NULL,
  `marriage_hall_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service_line`
--

INSERT INTO `service_line` (`service_line_id`, `service_id`, `service_line_name`, `service_per_unit_charges`, `service_description`, `marriage_hall_id`) VALUES
(6, 5, 'DJ', 5000, 'upon your request', 3),
(7, 5, 'DJ', 5000, 'upon your request', 4),
(8, 5, 'Photographer', 25000, 'upon your request', 4);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `role` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `first_name`, `last_name`, `email`, `phone`, `address`, `role`, `status`) VALUES
(8, 'superadmin', 'malaikarh_96', 'Super', 'Admin', 'superadmin96@gmail.com', '03707123407', 'Kharian village naseera', 0, 1),
(10, 'attiaadmin', '12345678', 'Attia ', 'Asir', 'itxmalaika56@gmail.com', '03167187688', 'Kharian village naseera', 1, 1),
(17, 'itxamber56', 'amber123', 'Amber', 'Amir', 'amber56@gmail.com', '03117936068', 'abbottabad', 2, 1),
(18, 'rubab56', 'rubab124', 'rubab', 'Amir', 'rubab56@gmail.com', '03125682641', 'gujrat', 2, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_booking`
-- (See below for the actual view)
--
CREATE TABLE `view_booking` (
`user_id` int(11)
,`first_name` text
,`last_name` text
,`email` varchar(255)
,`phone` varchar(255)
,`address` text
,`service_line_name` varchar(255)
,`service_description` text
,`marriage_hall_id` int(11)
,`marriage_hall_line_id` int(11)
,`capacity` int(11)
,`marriage_hall_line_name` varchar(255)
,`floor` int(11)
,`booking_id` int(11)
,`booking_date` date
,`guests` int(11)
,`booking_shift` int(11)
,`booking_bill` int(11)
,`booking_discount` int(11)
,`booking_reserve_payment` int(11)
,`status` int(11)
,`booking_line_id` int(11)
,`service_line_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_service`
-- (See below for the actual view)
--
CREATE TABLE `view_service` (
`service_name` varchar(255)
,`service_line_id` int(11)
,`service_id` int(11)
,`service_line_name` varchar(255)
,`service_per_unit_charges` float
,`service_description` text
,`marriage_hall_id` int(11)
);

-- --------------------------------------------------------

--
-- Structure for view `view_booking`
--
DROP TABLE IF EXISTS `view_booking`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_booking`  AS SELECT `users`.`user_id` AS `user_id`, `users`.`first_name` AS `first_name`, `users`.`last_name` AS `last_name`, `users`.`email` AS `email`, `users`.`phone` AS `phone`, `users`.`address` AS `address`, `service_line`.`service_line_name` AS `service_line_name`, `service_line`.`service_description` AS `service_description`, `marriage_hall`.`marriage_hall_id` AS `marriage_hall_id`, `marriage_hall_line`.`marriage_hall_line_id` AS `marriage_hall_line_id`, `marriage_hall_line`.`capacity` AS `capacity`, `marriage_hall_line`.`marriage_hall_line_name` AS `marriage_hall_line_name`, `marriage_hall_line`.`floor` AS `floor`, `booking`.`booking_id` AS `booking_id`, `booking`.`booking_date` AS `booking_date`, `booking`.`guests` AS `guests`, `booking`.`booking_shift` AS `booking_shift`, `booking`.`booking_bill` AS `booking_bill`, `booking`.`booking_discount` AS `booking_discount`, `booking`.`booking_reserve_payment` AS `booking_reserve_payment`, `booking`.`status` AS `status`, `booking_line`.`booking_line_id` AS `booking_line_id`, `booking_line`.`service_line_id` AS `service_line_id` FROM (((((`users` join `service_line`) join `booking`) join `booking_line`) join `marriage_hall`) join `marriage_hall_line`) WHERE `users`.`user_id` = `booking`.`user_id` AND `booking`.`booking_id` = `booking_line`.`booking_id` AND `booking`.`marriage_hall_line_id` = `marriage_hall_line`.`marriage_hall_line_id` AND `marriage_hall`.`marriage_hall_id` = `booking`.`marriage_hall_id` AND `booking_line`.`service_line_id` = `service_line`.`service_line_id` ;

-- --------------------------------------------------------

--
-- Structure for view `view_service`
--
DROP TABLE IF EXISTS `view_service`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_service`  AS SELECT `services`.`service_name` AS `service_name`, `service_line`.`service_line_id` AS `service_line_id`, `service_line`.`service_id` AS `service_id`, `service_line`.`service_line_name` AS `service_line_name`, `service_line`.`service_per_unit_charges` AS `service_per_unit_charges`, `service_line`.`service_description` AS `service_description`, `service_line`.`marriage_hall_id` AS `marriage_hall_id` FROM (`services` join `service_line`) WHERE `services`.`service_id` = `service_line`.`service_id` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `booking_line`
--
ALTER TABLE `booking_line`
  ADD PRIMARY KEY (`booking_line_id`);

--
-- Indexes for table `marriage_hall`
--
ALTER TABLE `marriage_hall`
  ADD PRIMARY KEY (`marriage_hall_id`);

--
-- Indexes for table `marriage_hall_line`
--
ALTER TABLE `marriage_hall_line`
  ADD PRIMARY KEY (`marriage_hall_line_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`service_id`);

--
-- Indexes for table `service_line`
--
ALTER TABLE `service_line`
  ADD PRIMARY KEY (`service_line_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `booking_line`
--
ALTER TABLE `booking_line`
  MODIFY `booking_line_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `marriage_hall`
--
ALTER TABLE `marriage_hall`
  MODIFY `marriage_hall_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `marriage_hall_line`
--
ALTER TABLE `marriage_hall_line`
  MODIFY `marriage_hall_line_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `service_line`
--
ALTER TABLE `service_line`
  MODIFY `service_line_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
